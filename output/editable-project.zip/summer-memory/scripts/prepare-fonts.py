from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools import subset
from pathlib import Path
chars='那时我们天天在一起太幸福到不需要距离很贪心要全世界注意只是年轻快乐和伤都像演戏碰就惊动地今看你昨去了哪里年夏躲这一大片宁静的海直到后来还对这个充满期待冬已经我的空出块高兴遇见让我终究明白回忆真精彩相爱告别重播青春记保存删除打开连接正在读取无法找到文件夏季冬季系统取消确定继续共同记视图窗口记事本日历每再一次温柔释怀音乐原唱王凌时间愿把留给自己请稍候播放完成恢复有无在线离线从前现在彼此也可惜过世界剧场错失返回学会可以总份永远平行宇宙轨道所有数据状态记住启结束次序标题' + ''.join(chr(i) for i in range(32,127))
chars += ''.join(p.read_text() for p in Path('src').rglob('*.tsx'))
f=TTFont('public/fonts/NotoSansSC-VF.ttf'); f=instantiateVariableFont(f,{'wght':900},inplace=True)
o=subset.Options();  sub=subset.Subsetter(options=o);sub.populate(text=chars);sub.subset(f); f.save('public/fonts/SummerBlack.ttf')
print('Bundled black display font',Path('public/fonts/SummerBlack.ttf').stat().st_size)
