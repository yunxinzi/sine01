import { bundle } from "@remotion/bundler";
import { openBrowser, selectComposition } from "@remotion/renderer";
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
const require = createRequire(import.meta.url);
const dist = path.dirname(require.resolve("@remotion/renderer"));
const { prepareServer } = require(path.join(dist, "prepare-server.js"));
const { setPropsAndEnv } = require(path.join(dist, "set-props-and-env.js"));
const { seekToFrame } = require(path.join(dist, "seek-to-frame.js"));
const timeline = JSON.parse(fs.readFileSync("lyrics-timing.json", "utf8"));
const bundlePath = await bundle({ entryPoint: path.resolve("src/index.ts") });
const server = await prepareServer({
  webpackConfigOrServeUrl: bundlePath,
  port: null,
  remotionRoot: process.cwd(),
  offthreadVideoThreads: 1,
  logLevel: "error",
  indent: false,
  offthreadVideoCacheSizeInBytes: null,
  binariesDirectory: null,
  forceIPv4: true,
  sampleRate: 48000,
});
const browser = await openBrowser("chrome", {
  browserExecutable: process.env.CHROME_PATH ?? "/usr/bin/chromium",
  logLevel: "error",
});
const errors = [];
const warnings = [];
const samples = [];
try {
  const comp = await selectComposition({
    serveUrl: server.serveUrl,
    id: "SummerMemory",
    puppeteerInstance: browser,
  });
  const page = await browser.newPage({
    context: server.sourceMap,
    logLevel: "error",
    indent: false,
    pageIndex: 0,
    onBrowserLog: (l) => {
      if (l.type === "error") errors.push(l.text);
    },
    onLog: () => {},
  });
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
  await setPropsAndEnv({
    page,
    serveUrl: server.serveUrl,
    serializedInputPropsWithCustomSchema: "{}",
    envVariables: {},
    initialFrame: 0,
    timeoutInMilliseconds: 30000,
    proxyPort: server.offthreadPort,
    retriesRemaining: 0,
    audioEnabled: false,
    videoEnabled: true,
    indent: false,
    logLevel: "error",
    onServeUrlVisited: () => {},
    isMainTab: true,
    mediaCacheSizeInBytes: 512 * 1024 * 1024,
    initialMemoryAvailable: 8 * 1024 ** 3,
    darkMode: false,
    sampleRate: 48000,
  });
  await page.evaluate(
    (c) =>
      window.remotion_setBundleMode({
        type: "composition",
        compositionName: c.id,
        serializedResolvedPropsWithSchema: JSON.stringify(c.props),
        compositionDurationInFrames: c.durationInFrames,
        compositionFps: c.fps,
        compositionHeight: c.height,
        compositionWidth: c.width,
        compositionDefaultCodec: null,
        compositionDefaultOutName: null,
        compositionDefaultVideoImageFormat: null,
        compositionDefaultPixelFormat: null,
        compositionDefaultProResProfile: null,
        compositionDefaultSampleRate: null,
      }),
    comp,
  );
  const frames = new Set([0, 75, 220, timeline.durationInFrames - 1]);
  for (const a of timeline.segments) {
    for (const t of [0, 3, 0.4, 0.75, 0.95])
      frames.add(
        a.from +
          (t < 1
            ? Math.floor((a.duration - 1) * t)
            : Math.min(t, a.duration - 1)),
      );
    if (a.words)
      for (const w of a.words)
        frames.add(
          a.from +
            Math.min(a.duration - 1, Math.round((w.startMs / 1000) * 30) + 12),
        );
  }
  for (const frame of [...frames].sort((a, b) => a - b)) {
    await seekToFrame({
      frame,
      page,
      composition: "SummerMemory",
      timeoutInMilliseconds: 30000,
      logLevel: "error",
      indent: false,
      attempt: 1,
    });
    const result = await page.evaluate(() => {
      const nodes = [...document.querySelectorAll("[data-safe]")].filter((n) =>
        n.checkVisibility({ opacityProperty: true, visibilityProperty: true }),
      );
      const boxes = nodes
        .map((n) => {
          const r = n.getBoundingClientRect();
          return {
            kind: n.dataset.safe,
            text: n.textContent,
            x: r.x,
            y: r.y,
            w: r.width,
            h: r.height,
          };
        })
        .filter((r) => r.w > 10 && r.h > 10);
      const out = boxes.filter(
        (r) => r.x < 24 || r.y < 62 || r.x + r.w > 1896 || r.y + r.h > 1004,
      );
      const overlaps = [];
      for (let i = 0; i < boxes.length; i++)
        for (let j = i + 1; j < boxes.length; j++) {
          const a = boxes[i],
            b = boxes[j];
          const ix = Math.max(
            0,
            Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x),
          );
          const iy = Math.max(
            0,
            Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y),
          );
          const ratio = (ix * iy) / Math.min(a.w * a.h, b.w * b.h);
          if (ratio > 0.18) overlaps.push({ a: a.text, b: b.text, ratio });
        }
      return {
        boxes,
        out,
        overlaps,
        replacementGlyph: boxes.some((b) => b.text.includes("\uFFFD")),
        fontReady: document.fonts.check("900 100px SummerBlack"),
      };
    });
    samples.push({ frame, ...result });
    if (result.out.length)
      warnings.push({ frame, kind: "bounds", items: result.out });
    if (result.overlaps.length)
      warnings.push({ frame, kind: "text-overlap", items: result.overlaps });
    if (result.replacementGlyph || !result.fontReady)
      errors.push({ frame, result });
  }
  const report = {
    checkedFrames: samples.length,
    scope:
      "DOM typography safety, text overlap, replacement characters and loaded font. Entrance overshoot and intended theatrical masking are reviewed separately using rendered frames.",
    errors,
    warnings,
    samples,
  };
  fs.writeFileSync("output/layout-qa.json", JSON.stringify(report, null, 2));
  console.log(
    "Layout QA",
    samples.length,
    "frames;",
    errors.length,
    "errors;",
    warnings.length,
    "review warnings",
  );
  console.log(JSON.stringify(warnings.slice(0, 18), null, 2));
  if (errors.length) process.exitCode = 1;
} finally {
  await browser.close({ silent: true });
  await server.closeServer(true);
}
