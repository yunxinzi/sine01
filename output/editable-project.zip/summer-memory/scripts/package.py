from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parent.parent
files=[root/n for n in ['README.md','storyboard.md','lyrics-timing.json','package.json','package-lock.json','tsconfig.json','requirements-helpers.txt','remotion.config.ts','eslint.config.mjs','.gitignore','.prettierrc']]
for name in ['src','scripts','public']:
 files+=list((root/name).rglob('*'))
files += [root/'assets/source.lrc',root/'assets/source.yrc',root/'assets/source-word-timing.json',root/'assets/source-metadata.json']
files += list((root/'output').glob('*qa*.json'))+[root/'output/alignment-evidence.json']
files += list((root/'screenshots/final').glob('*'))
files += list((root/'screenshots').glob('final-review-*.jpg'))+[root/'screenshots/closing.jpg',root/'screenshots/fixed-bridge-final.jpg']
with ZipFile(root/'output/editable-project.zip','w',ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,'summer-memory/'+str(p.relative_to(root)))
print('Editable project bundle:',(root/'output/editable-project.zip').stat().st_size,'bytes')
