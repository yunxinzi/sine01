import sys,struct,json,base64
from pathlib import Path
sys.path.insert(0,'/workspace/.python')
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
p=Path(sys.argv[1]); data=p.read_bytes(); assert data[:8]==b'CTENFDAM'
pos=10
n=struct.unpack_from('<I',data,pos)[0]; pos+=4
key=unpad(AES.new(b'hzHRAmso5kInbaxW',AES.MODE_ECB).decrypt(bytes(x^0x64 for x in data[pos:pos+n])),16)[17:];pos+=n
box=list(range(256)); last=0;ki=0
for i in range(256):
 c=(box[i]+last+key[ki])&255; box[i],box[c]=box[c],box[i];last=c;ki=(ki+1)%len(key)
n=struct.unpack_from('<I',data,pos)[0];pos+=4
meta=bytes(x^0x63 for x in data[pos:pos+n]);pos+=n
meta=unpad(AES.new(bytes.fromhex('2331346c6a6b5f215c5d2630553c2728'),AES.MODE_ECB).decrypt(base64.b64decode(meta[22:])),16)
metadata=json.loads(meta[6:]); print(json.dumps({k:metadata.get(k) for k in ['musicName','artist','format','duration']},ensure_ascii=False))
pos+=9
n=struct.unpack_from('<I',data,pos)[0];pos+=4+n
stream=bytes(box[(box[j]+box[(box[j]+j)&255])&255] for j in list(range(1,256))+[0])
out=bytearray(data[pos:])
for i in range(len(out)): out[i]^=stream[i&255]
ext=metadata.get('format','mp3'); target=Path(sys.argv[2]);target.mkdir(parents=True,exist_ok=True)
(target/('source.'+ext)).write_bytes(out)
(target/'source-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
print('Decoded',len(out),'bytes; audio signature',bytes(out[:4]))
