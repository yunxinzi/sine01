import json,re,math,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
words=json.loads((root/'assets/source-word-timing.json').read_text())
if (root/'lyrics-timing.json').exists() and '--source' not in sys.argv:
 edited=json.loads((root/'lyrics-timing.json').read_text())
 words=[{'text':r['text'],'startMs':r['startMs'],'endMs':r['endMs'],'words':r['words']} for r in edited['lines']]
analysis=json.loads((root/'src/audio-analysis.json').read_text())
names=['Calendar','Distance','World','Young','Emotion','Theatre','Impact','Today','Yesterday','Summer','QuietSea','Later','Expect','Winter','MissingHeart','Meet','Understand','Memory']
scenes=names*2+['Effort','Promise','Learning','Difficult']+names[9:]
assert len(scenes)==len(words)==49
fps=30;total=math.ceil(analysis['duration']*fps)
lines=[];parts=[]
for i,(row,scene) in enumerate(zip(words,scenes)):
 next_start=words[i+1]['startMs'] if i+1<len(words) else row['endMs']
 # Give instrumental gaps longer than 4 seconds their own authored scene.
 display_end=min(next_start,row['endMs']+900) if next_start-row['endMs']>4000 else next_start
 startFrame=round(row['startMs']/1000*fps);endFrame=round(display_end/1000*fps)
 local=[{**w,'startMs':w['startMs']-row['startMs'],'endMs':w['endMs']-row['startMs'],'timestampMs':w['startMs']-row['startMs']} for w in row['words']]
 accents=[round((a['time']-row['startMs']/1000)*fps) for a in analysis['onsets'] if row['startMs']/1000<=a['time']<display_end/1000 and a['strength']>.2]
 variant=0 if i<18 else 1 if i<36 else 2
 r={**row,'scene':scene,'startFrame':startFrame,'endFrame':endFrame,'variant':variant,'accents':accents,'wordAlignment':'source YRC v3; no invented or evenly spaced syllable timestamps'};lines.append(r)
 parts.append({'scene':scene,'from':startFrame,'duration':endFrame-startFrame,'text':row['text'],'words':local,'variant':variant,'accents':accents})
 if display_end<next_start:parts.append({'scene':'Interlude','from':endFrame,'duration':round(next_start/1000*fps)-endFrame,'variant':variant})
parts.insert(0,{'scene':'Opening','from':0,'duration':lines[0]['startFrame']})
parts.append({'scene':'Ending','from':lines[-1]['endFrame'],'duration':total-lines[-1]['endFrame']})
# Ensure the full original audio is covered exactly, with no black or uncovered gaps.
assert sum(a['duration'] for a in parts)==total
for a,b in zip(parts,parts[1:]):assert a['from']+a['duration']==b['from']
timing={'song':'那年夏天宁静的海','artist':'王心凌','sourceMusicId':297578,'audioFile':'public/music.mp3','durationSeconds':analysis['duration'],'fps':fps,'durationInFrames':total,'source':{'line':'assets/source.lrc, source LRC v9','word':'assets/source.yrc, source YRC v3','endpoint':'https://music.163.com/api/song/lyric/v1?id=297578&lv=-1&kv=-1&tv=-1&rv=-1&yv=-1&ytv=-1&yrv=-1&cp=false'},'alignment':{'method':'Source YRC word timestamps; compared against measured high-frequency spectral transients. YRC chosen over older LRC because YRC exhibits the best onset agreement at a 0.12-second acoustic attack lag, rather than the ~2.1-second LRC shift. No timestamps created by averaging lyric lengths.','sourceOffsetMs':0,'verifiedByHumanListening':False,'asrVerified':False,'reviewNote':'Source-provided timing, editable here. A spectral onset check is supportive evidence, not a forced-alignment or word-recognition proof.'},'lines':lines,'segments':parts}
(root/'lyrics-timing.json').write_text(json.dumps(timing,ensure_ascii=False,indent=2)+'\n')
# Every production scene is an authored JSX node, editable independently in Studio.
s="import {AbsoluteFill,useVideoConfig} from 'remotion';\nimport {"+','.join(sorted(set(a['scene'] for a in parts)))+"} from './registry';\nimport {Soundtrack,Progress} from './Film';\nexport const ProductionTimeline=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><Soundtrack/>\n"
for i,a in enumerate(parts):
 props={'name':str(i+1).zfill(2)+' / '+a.get('text',a['scene']),'from':a['from'],'durationInFrames':a['duration'],'premountFor':None,'duration':a['duration'],'start':a['from']/fps,'variant':a.get('variant',0)}
 s+=f"<{a['scene']} "+' '.join(k+'={'+json.dumps(v,ensure_ascii=False)+'}' if k!='premountFor' else 'premountFor={fps}' for k,v in props.items())
 if 'text' in a:s+=' text={'+json.dumps(a['text'],ensure_ascii=False)+'} words={'+json.dumps(a['words'],ensure_ascii=False)+'} accents={'+json.dumps(a['accents'])+'}'
 s+='/ >\n'
s+='<Progress/></AbsoluteFill>;};\n';s=s.replace('/ >','/>')
# Wrap each original component in a timed, source-editable Sequence (the scene reference stays connected).
s=s.replace("import {AbsoluteFill,useVideoConfig}","import {AbsoluteFill,Sequence,useVideoConfig}")
for a in sorted(set(x['scene'] for x in parts)):
 # Move timing props from scene to the authored Sequence.
 pattern=r'<'+a+r' name=\{([^\n]+?)\} from=\{(\d+)\} durationInFrames=\{(\d+)\} premountFor=\{fps\} ([^\n]+?)/>'
 s=re.sub(pattern,lambda m:'<Sequence name={'+m[1]+'} from={'+m[2]+'} durationInFrames={'+m[3]+'} premountFor={fps}><'+a+' '+m[4]+'/></Sequence>',s)
s=s.replace(' from={0}','')
(root/'src/ProductionTimeline.tsx').write_text(s)
# The full timeline and the sample range point to the very same frames and the same audio.
p=root/'src/Root.tsx';s=p.read_text()
s="import {ProductionTimeline} from './ProductionTimeline';\n"+s if not re.search(r"import\s*\{\s*ProductionTimeline\s*\}",s) else s
if 'id="SummerMemory"' not in s:s=s.replace('<Composition id="DesignSample"',f'<Composition id="SummerMemory" component={{ProductionTimeline}} durationInFrames={{{total}}} fps={{30}} width={{1920}} height={{1080}} defaultProps={{{{sampleFrom:1208}}}}/>\n <Composition id="DesignSample"')
s=s.replace('Memory,Opening,Interlude,Ending}', 'Memory,Opening,Interlude,Ending,Effort,Promise,Learning,Difficult}')
if 'id="Effort"' not in s:
 s=s.replace('</Folder>', ''.join(f'<Composition id="{id}" component={{{id}}} durationInFrames={{180}} fps={{30}} width={{1920}} height={{1080}}/>\n' for id in ['Effort','Promise','Learning','Difficult'])+'</Folder>')
p.write_text(s)
print('Full production timeline:',len(lines),'lyric scenes;',len(parts),'segments;',total,'frames')
