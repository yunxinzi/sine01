import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
  openBrowser,
} from "@remotion/renderer";
import path from "node:path";
import fs from "node:fs";
const mode = process.argv[2] ?? "final";
const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  onProgress: (p) => {
    if (p === 100) console.log("Bundle ready");
  },
});
const browser = await openBrowser("chrome", {
  browserExecutable: process.env.CHROME_PATH ?? "/usr/bin/chromium",
  chromiumOptions: { disableWebSecurity: false },
  logLevel: "error",
});
try {
  if (mode === "stills") {
    const ids = [
      "Calendar",
      "Distance",
      "World",
      "Young",
      "Emotion",
      "Theatre",
      "Impact",
      "Today",
      "Yesterday",
      "Summer",
      "QuietSea",
      "Later",
      "Expect",
      "Winter",
      "MissingHeart",
      "Meet",
      "Understand",
      "Memory",
      "Opening",
      "Interlude",
      "Ending",
    ];
    for (const id of ids) {
      const c = await selectComposition({
        serveUrl,
        id,
        puppeteerInstance: browser,
      });
      await renderStill({
        serveUrl,
        composition: c,
        frame: id === "Opening" ? 220 : 75,
        output: `screenshots/${id}.png`,
        puppeteerInstance: browser,
      });
      console.log("Still", id);
    }
  } else {
    const id = mode === "design" ? "DesignSample" : "SummerMemory";
    if (id === "SummerMemory" && !fs.existsSync("src/ProductionTimeline.tsx"))
      throw new Error(
        "Genuine lyric timestamps have not been imported. Refusing to fabricate an aligned film.",
      );
    const c = await selectComposition({
      serveUrl,
      id,
      puppeteerInstance: browser,
    });
    let last = -1;
    const patchSegment =
      mode === "patch"
        ? JSON.parse(
            fs.readFileSync("lyrics-timing.json", "utf8"),
          ).segments.find((s) => s.scene === process.argv[3])
        : null;
    if (mode === "patch" && !patchSegment)
      throw new Error("Unknown patch scene");
    const opt =
      mode === "patch"
        ? {
            outputLocation: "output/patch.mp4",
            frameRange: [
              patchSegment.from,
              patchSegment.from + patchSegment.duration - 1,
            ],
            muted: true,
            crf: 17,
          }
        : mode === "design"
          ? { outputLocation: "output/design-study.mp4" }
          : mode === "sample"
            ? {
                outputLocation: "output/sample.mp4",
                frameRange: [c.props.sampleFrom, c.props.sampleFrom + 209],
              }
            : mode === "preview"
              ? { outputLocation: "output/preview.mp4", scale: 0.5, crf: 24 }
              : { outputLocation: "output/final.mp4", crf: 17 };
    await renderMedia({
      serveUrl,
      composition: c,
      codec: "h264",
      audioCodec: "aac",
      audioBitrate: "320k",
      pixelFormat: "yuv420p",
      concurrency: 3,
      puppeteerInstance: browser,
      imageFormat: "jpeg",
      jpegQuality: 96,
      logLevel: "warn",
      ...opt,
      onProgress: ({ progress, renderedFrames }) => {
        const pct = Math.floor(progress * 100);
        if (pct >= last + 5) {
          last = pct;
          console.log(`Render ${pct}% / ${renderedFrames} frames`);
        }
      },
    });
    console.log("Rendered", opt.outputLocation);
  }
} finally {
  await browser.close({ silent: true });
}
