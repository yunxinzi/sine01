import subprocess,json,numpy as np
from pathlib import Path
from scipy.signal import correlate,correlation_lags
root=Path(__file__).resolve().parent.parent; movie=root/'output/final.mp4'; timing=json.loads((root/'lyrics-timing.json').read_text())
def run(args): return subprocess.run(args,check=True,capture_output=True)
p=json.loads(run(['ffprobe','-v','error','-count_frames','-show_entries','format=duration:stream=codec_name,width,height,r_frame_rate,nb_read_frames,duration,start_time','-of','json',str(movie)]).stdout)
v=next(s for s in p['streams'] if 'width' in s);a=next(s for s in p['streams'] if s['codec_name']=='aac')
assert v['width']==1920 and v['height']==1080 and v['codec_name']=='h264' and v['r_frame_rate']=='30/1'
assert int(v['nb_read_frames'])==timing['durationInFrames']
assert abs(float(v['duration'])-timing['durationSeconds'])<1/30
# Decode all video+audio, preserving FFmpeg's exit status. A decode failure must fail the audit.
d=run(['ffmpeg','-hide_banner','-v','error','-i',str(movie),'-f','null','-'])
black=run(['ffmpeg','-hide_banner','-loglevel','info','-i',str(movie),'-vf','blackdetect=d=0.1:pix_th=0.04:pic_th=0.99','-an','-f','null','-']).stderr.decode()
blackevents=[l for l in black.splitlines() if 'black_start:' in l]
assert not blackevents,blackevents
# Confirm source and muxed audio have the same content and no accumulating drift.
run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(movie),'-vn','-ar','16000','-ac','1','-f','f32le','-y','/tmp/final-audio.f32'])
run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(root/'public/music.mp3'),'-vn','-ar','16000','-ac','1','-f','f32le','-y','/tmp/original-audio.f32'])
src=np.fromfile('/tmp/original-audio.f32',dtype='float32');out=np.fromfile('/tmp/final-audio.f32',dtype='float32'); audio=[]
for start in [15,43,85,120,174,205,235]:
 i=int(start*16000);n=6*16000;x=src[i:i+n];y=out[i:i+n]
 c=correlate(y,x,method='fft');lag=int(correlation_lags(len(y),len(x))[np.argmax(c)])
 if lag>=0:b=y[lag:];aa=x[:len(b)]
 else:aa=x[-lag:];b=y[:len(aa)]
 rho=float(np.corrcoef(aa,b)[0,1]); audio.append({'sourceTimeSeconds':start,'lagSeconds':lag/16000,'correlation':rho})
 assert abs(lag)/16000<1/30 and rho>.98,audio[-1]
# Extract actual final-video frames, one per sung line plus intro/interlude/outro.
frames=[220]
for line in timing['lines']:
 frames.append(min(line['endFrame']-2,round(line['words'][-1]['startMs']/1000*30)+20))
frames += [timing['durationInFrames']-75];frames=sorted(set(frames))
expr='+'.join('eq(n\\,'+str(f)+')' for f in frames)
(root/'screenshots/final').mkdir(exist_ok=True)
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(movie),'-vf','select='+expr,'-fps_mode','vfr','-q:v','2',str(root/'screenshots/final/frame-%02d.jpg')])
(root/'screenshots/final/frame-map.json').write_text(json.dumps(frames))
report={'status':'passed','video':v,'audio':a,'sourceDurationSeconds':timing['durationSeconds'],'containerDurationSeconds':float(p['format']['duration']),'fullDecodePassed':True,'blackIntervals':blackevents,'audioCorrelationChecks':audio,'renderedFramesInspected':len(frames),'layoutAuditFile':'layout-qa.json','alignmentLimit':'YRC source timestamps plus acoustic transient evidence; not an ASR or human listening proof.'}
(root/'output/media-qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
