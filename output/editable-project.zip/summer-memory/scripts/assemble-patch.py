import subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
x=json.loads((root/'lyrics-timing.json').read_text());p=next(s for s in x['segments'] if s['scene']=='Difficult');start=p['from'];end=start+p['duration']
expr=f'[0:v]split=2[a][b];[a]trim=end_frame={start},setpts=PTS-STARTPTS[pre];[1:v]setpts=PTS-STARTPTS[fix];[b]trim=start_frame={end},setpts=PTS-STARTPTS[post];[pre][fix][post]concat=n=3:v=1:a=0[v]'
out=root/'output/final-fixed.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(root/'output/final.mp4'),'-i',str(root/'output/patch.mp4'),'-filter_complex',expr,'-map','[v]','-map','0:a:0','-c:v','libx264','-preset','fast','-crf','17','-threads','3','-pix_fmt','yuv420p','-r','30','-c:a','copy','-movflags','+faststart',str(out)],check=True)
probe=json.loads(subprocess.run(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames,width,height,r_frame_rate','-of','json',str(out)],check=True,capture_output=True).stdout)
assert int(probe['streams'][0]['nb_read_frames'])==x['durationInFrames']
original=root/'output/final.mp4';original.rename(root/'output/final-before-ui-fix.mp4');out.rename(original)
print('Patched authored Remotion segment',start,end-1,'with original audio copied unchanged;',x['durationInFrames'],'video frames preserved')
