# 那年夏天宁静的海 · 动态歌词 MG

完整 React + TypeScript + Remotion 工程。使用用户上传的歌曲音源，输出 1920×1080 / 30 FPS / H.264 + AAC。全长约 4 分 11 秒，包含 49 行演唱歌词、四句桥段、前奏、间奏和尾奏。

## 交付

- `output/final.mp4`：完整高清成片。
- `output/preview.mp4`：完整时长的轻量预览。
- `output/sample.mp4`：7 秒实渲样片，覆盖「演戏 → 惊天动地 → 今天」。
- `src/`：全部可编辑动画；独立场景在 `src/scenes/`。
- `lyrics-timing.json`：真实来源逐字时间轴，含来源和验证边界。
- `storyboard.md`：参考研究、原创设计系统、49 行分镜。
- `screenshots/`：场景与实际成片关键帧。
- `output/*qa*.json`、`output/alignment-evidence.json`：审查证据。

## 环境与运行

Node.js 22 或 24、npm、FFmpeg、Chromium。Remotion 与所有 @remotion 包固定在 4.0.535。当前云环境已安装并验证 Node 24、FFmpeg 7.1、Chromium 154。Remotion 官方 Agent Skills 已在用户级目录安装。

```bash
cd /workspace/sine01
npm ci --cache /workspace/.cache/npm
npm run dev -- --port=3000
```

Studio 里选择 `SummerMemory` 查看全片；`Scenes` 下可单独修改各个场景。云环境不提供可分享的 localhost 网页预览，直接查看 MP4 交付物即可。

```bash
npm run typecheck
npm run sample
npm run render
npm run qa
```

默认使用 `/usr/bin/chromium`；其他机器可设置 `CHROME_PATH` 指向 Chromium/Chrome 可执行文件。渲染采用 3 个并发页；可在 `scripts/render.mjs` 修改。

创建轻量预览（使用已渲染成片，无需再次渲染动画）：

```bash
ffmpeg -i output/final.mp4 -vf scale=1280:-2 -c:v libx264 -crf 25 -preset fast -c:a aac -b:a 160k output/preview.mp4
```

## 修改方法

配色、字体、像素角色、弹窗、字幕与常用运动位于 `src/design.tsx`。每个歌词场景有独立 TSX 文件，帧驱动弹性、位移、遮挡和 SVG 路径构成动画，不使用 CSS 时间动画。`src/ProductionTimeline.tsx` 的每个片段是独立 JSX 节点，可修改位置、持续时间、文字与逐字时间。

`lyrics-timing.json` 各行的 `words` 是绝对源时间（毫秒）；生产 TSX 节点上的 words 是对应场景的局部时间。想精修音画同步，直接修改该节点上的局部 startMs/endMs，或修改 `lyrics-timing.json` 中的绝对时间，再运行下面的生成器。生成器默认保留该 JSON 的手工修正；只有添加 `--source` 参数才重新读取原始 YRC。同时保持行级 startMs/endMs 与逐字时间一致。生成器会重建生产 TSX，不保留对此生成文件的手工修改；运行前先保存手工版本。

```bash
python scripts/build-timeline.py
python scripts/write-docs.py
npm run typecheck
npm run render
```

字体使用官方 Google Fonts 的 Noto Sans SC 900 字重。子集包含所有当前歌词和 UI 字形；完整源字体保留在 `public/fonts/NotoSansSC-VF.ttf`。如添加其他汉字，运行 `python scripts/prepare-fonts.py`，需要 `fonttools`；无需联网获取字体。各处尺寸以 1920×1080 为设计坐标。

`public/music.mp3` 是从本次用户上传的 NCM 解码得到的完整 MP3。没有使用参考视频画面或水印作为成片素材。`reference/` 的截图仅是研究证据。

## 时间戳与验证边界

歌词来源是同一歌曲 ID 的 LRC v9 和逐字 YRC v3。采用 YRC，保留原始逐字值，不平均分配时间。高频谱通量、样片/成片与原音频相关性、字形覆盖、布局及真实编码输出均可自动检查。谱通量只支持音频时序判断，不能证明每个字已完成语音强制对齐；本工程没有声称经过人工逐字听审。可通过时间轴继续精修。

可选 Python 辅助脚本（字体子集、时间轴生成、成片审查）需要 Python 3.12。运行 `python -m pip install -r requirements-helpers.txt` 安装其固定依赖。正常 Studio 编辑与 Remotion 渲染不依赖这些 Python 包。

自动布局脚本使用固定版本 Remotion 的内部浏览器接口，升级 Remotion 时应同时复核该脚本。字体许可证为 SIL Open Font License，随工程附带。Remotion 的许可证使用条件以官方文档为准。

## 本次实渲审查结果

7543 帧完整解码通过，黑帧扫描无结果；622 个帧位的文字布局检查无越界或文字重叠，109 个歌词汉字全部有字形。51 张真实成片关键帧及结尾已检查；桥段「继续」按钮对比度问题已修复并重新渲染。7 个不同音乐位置的音轨相关系数均大于 0.999，偏移均约 25ms，未发现累积漂移。歌词对齐仍按前述来源 YRC 和信号证据理解，未进行人工逐字听审。
