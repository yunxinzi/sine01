import React, { createContext, useContext } from "react";
import type { Caption as WordCaption } from "@remotion/captions";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
  staticFile,
} from "remotion";
import { loadFont } from "@remotion/fonts";

loadFont({
  family: "SummerBlack",
  url: staticFile("fonts/SummerBlack.ttf"),
  weight: "900",
});
loadFont({
  family: "MemoryMono",
  url: staticFile("fonts/Mono.ttf"),
  weight: "400",
});
export const C = {
  paper: "#F2F0E8",
  ink: "#151515",
  blue: "#2856EB",
  orange: "#F47B45",
  pale: "#C8D4FA",
  yellow: "#FFCA48",
  gray: "#B8B7B1",
};
export const FONT = 'SummerBlack, "Noto Sans CJK SC", sans-serif';
export const MONO = "MemoryMono, monospace";
export const clamp = (f: number, a: number, b: number, x: number, y: number) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
export const pop = (f: number, delay = 0, damping = 13) =>
  spring({
    frame: f - delay,
    fps: 30,
    config: { damping, stiffness: 190, mass: 0.65 },
  });
export const enter = (f: number, delay = 0) =>
  spring({
    frame: f - delay,
    fps: 30,
    config: { damping: 22, stiffness: 220, mass: 0.7 },
  });
export const WordContext = createContext<WordCaption[] | undefined>(undefined);
export const wordFrame = (
  p: SceneProps,
  fragment: string,
  fallback: number,
) => {
  const w = p.words;
  if (!w) return fallback;
  const joined = w.map((a) => a.text.trim()).join("");
  const i = joined.indexOf(fragment.replace(/\s/g, ""));
  return i >= 0 ? (w[i].startMs / 1000) * 30 : fallback;
};
export type SceneProps = {
  words?: WordCaption[];
  text?: string;
  variant?: number;
  duration?: number;
  start?: number;
  accents?: number[];
};
export const useScene = (p: SceneProps) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const hit =
    p.accents?.reduce(
      (v, a) =>
        Math.max(v, Math.exp(-Math.max(0, f - a) / 5) * (f >= a ? 1 : 0)),
      0,
    ) ?? 0;
  return { f, fps, v: p.variant ?? 0, d: p.duration ?? 120, hit };
};
export const Label = ({
  children,
  x = 0,
  y = 0,
  color = C.ink,
  size = 21,
  style = {},
}: {
  children: React.ReactNode;
  x?: number;
  y?: number;
  color?: string;
  size?: number;
  style?: React.CSSProperties;
}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      fontFamily: MONO,
      fontSize: size,
      color,
      letterSpacing: 1,
      ...style,
    }}
  >
    {children}
  </div>
);
export const Stage = ({
  children,
  bg = C.paper,
  dark = false,
  chapter = "01 / 相遇",
  texture = true,
  words,
}: {
  words?: WordCaption[];
  children: React.ReactNode;
  bg?: string;
  dark?: boolean;
  chapter?: string;
  texture?: boolean;
}) => {
  const f = useCurrentFrame();
  const ink = dark ? C.paper : C.ink;
  return (
    <WordContext.Provider value={words}>
      <AbsoluteFill
        style={{
          backgroundColor: bg,
          color: ink,
          fontFamily: FONT,
          fontWeight: 900,
          overflow: "hidden",
        }}
      >
        {texture && (
          <AbsoluteFill
            style={{
              opacity: 0.14,
              backgroundImage: `radial-gradient(${dark ? "#AAA" : "#8C8B85"} 1px,transparent 1px)`,
              backgroundSize: "18px 18px",
              maskImage: "linear-gradient(90deg,transparent 45%,black)",
            }}
          />
        )}
        <div
          style={{
            position: "absolute",
            left: 56,
            right: 56,
            top: 53,
            height: 1,
            background: ink,
            opacity: 0.5,
          }}
        />
        <Label x={58} y={20} color={ink} size={17}>
          SUMMER.EXE / MEMORY SYSTEM
        </Label>
        <Label x={1310} y={20} color={ink} size={17}>
          {chapter}
        </Label>
        <div
          style={{
            position: "absolute",
            right: 60,
            top: 25,
            display: "flex",
            gap: 7,
          }}
        >
          {[C.ink, C.paper, C.blue, C.orange, C.yellow].map((c, i) => (
            <div
              key={i}
              style={{
                width: 12,
                height: 12,
                background: c,
                outline: `1px solid ${ink}`,
              }}
            />
          ))}
        </div>
        <div
          style={{
            position: "absolute",
            left: 56,
            right: 56,
            bottom: 49,
            height: 1,
            background: ink,
            opacity: 0.5,
          }}
        />
        <Label x={58} y={1010} size={17} color={ink}>
          A MEMORY IN FIVE ACTS
        </Label>
        <Label x={1560} y={1010} size={17} color={ink}>
          FRAME {String(Math.max(0, Math.floor(f))).padStart(5, "0")}
        </Label>
        {children}
      </AbsoluteFill>
    </WordContext.Provider>
  );
};
export const Text = ({
  children,
  x,
  y,
  size = 170,
  color = C.ink,
  delay = 0,
  mode = "rise",
  outline = false,
  shadow = false,
  rotate = 0,
  style = {},
  wordIndex,
}: {
  wordIndex?: number;
  children: string;
  x: number;
  y: number;
  size?: number;
  color?: string;
  delay?: number;
  mode?: "rise" | "slam" | "slide" | "none";
  outline?: boolean;
  shadow?: boolean;
  rotate?: number;
  style?: React.CSSProperties;
}) => {
  const f = useCurrentFrame();
  const words = useContext(WordContext);
  const joined = words?.map((a) => a.text.trim()).join("") ?? "";
  const ix =
    wordIndex ?? joined.indexOf(children.replace(/[\s\p{P}\p{S}]/gu, ""));
  const timedDelay = words && ix >= 0 ? (words[ix].startMs / 1000) * 30 : delay;
  const p = mode === "none" ? 1 : pop(f, timedDelay);
  const dx = mode === "slide" ? (1 - p) * -500 : 0;
  const dy = mode === "rise" ? (1 - p) * 140 : 0;
  return (
    <div
      data-safe="lyric"
      style={{
        position: "absolute",
        left: x,
        top: y,
        fontSize: size,
        lineHeight: 1.17,
        letterSpacing: "-.035em",
        whiteSpace: "nowrap",
        color: outline ? "transparent" : color,
        WebkitTextStroke: outline ? `3px ${color}` : undefined,
        textShadow: shadow ? `8px 8px 0 ${C.ink}` : undefined,
        opacity: f < timedDelay ? 0 : 1,
        transform: `translate(${dx}px,${dy}px) rotate(${rotate * (1 - p)}deg) scale(${mode === "slam" ? Math.max(0.05, p) : 1})`,
        transformOrigin: "50% 60%",
        ...style,
      }}
    >
      {[...children].map((ch, i) => (
        <span
          key={i}
          style={{
            display: "inline-block",
            translate:
              words && ix >= 0
                ? `0px ${-Math.sin(clamp(f, ((words[ix + i]?.startMs ?? 0) / 1000) * 30, ((words[ix + i]?.startMs ?? 0) / 1000) * 30 + 10, 0, Math.PI)) * size * 0.035}px`
                : undefined,
          }}
        >
          {ch}
        </span>
      ))}
    </div>
  );
};
export const Stagger = ({
  text,
  x,
  y,
  size = 190,
  color = C.ink,
  delay = 0,
  gap = 4,
  mode = "rise",
}: {
  text: string;
  x: number;
  y: number;
  size?: number;
  color?: string;
  delay?: number;
  gap?: number;
  mode?: "rise" | "slam" | "slide";
}) => {
  const words = useContext(WordContext);
  const index = (words?.map((w) => w.text.trim()).join("") ?? "").indexOf(text);
  return (
    <>
      {[...text].map((ch, i) => (
        <Text
          key={i}
          wordIndex={index >= 0 ? index + i : undefined}
          x={x + i * size * 0.965}
          y={y}
          size={size}
          color={color}
          delay={delay + i * gap}
          mode={mode}
          rotate={(i % 2 ? 1 : -1) * 12}
        >
          {ch}
        </Text>
      ))}
    </>
  );
};
export const Window = ({
  x,
  y,
  w,
  h,
  title = "memory.exe",
  children,
  bar = C.blue,
  scale = 1,
  rotate = 0,
  dark = false,
  style = {},
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  title?: string;
  children: React.ReactNode;
  bar?: string;
  scale?: number;
  rotate?: number;
  dark?: boolean;
  style?: React.CSSProperties;
}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: w,
      height: h,
      border: `4px solid ${C.ink}`,
      background: dark ? C.ink : C.paper,
      boxShadow: `10px 10px 0 ${C.ink}`,
      transform: `scale(${scale}) rotate(${rotate}deg)`,
      transformOrigin: "50% 50%",
      ...style,
    }}
  >
    <div
      style={{
        height: 47,
        background: bar,
        borderBottom: `3px solid ${C.ink}`,
        display: "flex",
        alignItems: "center",
        padding: "0 13px",
        color: C.paper,
        fontFamily: MONO,
        fontSize: 22,
        justifyContent: "space-between",
      }}
    >
      <span>{title}</span>
      <span style={{ display: "flex", gap: 8 }}>
        {["−", "□", "×"].map((s, i) => (
          <span
            key={i}
            style={{
              background: C.paper,
              color: C.ink,
              width: 26,
              height: 25,
              lineHeight: "24px",
              textAlign: "center",
              border: `2px solid ${C.ink}`,
              fontSize: 23,
            }}
          >
            {s}
          </span>
        ))}
      </span>
    </div>
    <div style={{ position: "relative", height: h - 55, overflow: "hidden" }}>
      {children}
    </div>
  </div>
);
export const Cursor = ({
  x,
  y,
  scale = 1,
  click = false,
}: {
  x: number;
  y: number;
  scale?: number;
  click?: boolean;
}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: 55,
      height: 65,
      transform: `scale(${scale})`,
      filter: `drop-shadow(4px 4px 0 ${C.paper})`,
    }}
  >
    <svg viewBox="0 0 50 60">
      <path
        d="M4 3V47L16 34L27 56L37 51L26 30L44 29Z"
        fill={C.ink}
        stroke={C.paper}
        strokeWidth="3"
      />
      {click && (
        <g stroke={C.orange} strokeWidth="4">
          <path d="M0 0L-15 -15M20 -5L23 -21M-8 20L-22 23" />
        </g>
      )}
    </svg>
  </div>
);
export const Pixel = ({
  x,
  y,
  size = 160,
  color = C.orange,
  mood = "happy",
  walk = 0,
  flip = false,
  opacity = 1,
  angle = 0,
}: {
  x: number;
  y: number;
  size?: number;
  color?: string;
  mood?: "happy" | "sad" | "shock" | "wink" | "sleep";
  walk?: number;
  flip?: boolean;
  opacity?: number;
  angle?: number;
}) => {
  const f = useCurrentFrame();
  const blink = f % 115 > 108;
  const stepping = Math.sin(walk) * 6;
  return (
    <svg
      aria-label="原创像素角色"
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: size,
        height: size * 0.88,
        imageRendering: "pixelated",
        opacity,
        transform: `rotate(${angle}deg) scaleX(${flip ? -1 : 1})`,
        overflow: "visible",
      }}
      viewBox="0 0 24 21"
      shapeRendering="crispEdges"
    >
      <g fill={color}>
        <path d="M5 3H18V5H21V8H24V13H21V17H3V14H0V9H3V5H5Z" />
        <rect x="6" y="0" width="3" height="4" />
        <rect x="16" y="1" width="3" height="4" />
        <rect
          x="4"
          y="16"
          width="4"
          height="4"
          transform={`translate(0 ${stepping / 4})`}
        />
        <rect
          x="16"
          y="16"
          width="4"
          height="4"
          transform={`translate(0 ${-stepping / 4})`}
        />
      </g>
      <g fill={C.ink}>
        {mood === "happy" ? (
          <>
            {blink ? (
              <path d="M6 8H10V9H6ZM14 8H18V9H14Z" />
            ) : (
              <path d="M6 8H7V7H9V8H10V9H9V8H7V9H6ZM14 8H15V7H17V8H18V9H17V8H15V9H14Z" />
            )}
            <rect x="10" y="12" width="4" height="1" />
          </>
        ) : mood === "sad" ? (
          <>
            <path d="M6 7L9 8V9H6ZM15 8L18 7V9H15Z" />
            <path d="M10 13V12H14V13Z" />
            <rect x="8" y="10" width="1" height="3" fill={C.blue} />
          </>
        ) : mood === "shock" ? (
          <>
            <rect x="6" y="7" width="3" height="4" />
            <rect x="15" y="7" width="3" height="4" />
            <rect x="10" y="12" width="4" height="3" />
          </>
        ) : mood === "wink" ? (
          <>
            <rect x="6" y="7" width="2" height="4" />
            <path d="M14 8H18V9H14Z" />
            <rect x="10" y="12" width="4" height="1" />
          </>
        ) : (
          <path d="M6 9H10V10H6ZM14 9H18V10H14Z" />
        )}
      </g>
      <path d="M4 11H7V12H4ZM17 11H20V12H17Z" fill={C.paper} opacity=".36" />
    </svg>
  );
};
export const Heart = ({
  x,
  y,
  size = 180,
  missing = false,
  color = C.orange,
  progress = 1,
}: {
  x: number;
  y: number;
  size?: number;
  missing?: boolean;
  color?: string;
  progress?: number;
}) => (
  <svg
    style={{ position: "absolute", left: x, top: y, width: size, height: size }}
    viewBox="0 0 11 11"
    shapeRendering="crispEdges"
  >
    <path
      d="M1 1H4V2H5V3H6V2H7V1H10V2H11V6H10V7H9V8H8V9H7V10H6V11H5V10H4V9H3V8H2V7H1V6H0V2H1Z"
      fill={color}
    />
    {missing && <path d="M6 3H9V6H8V7H6Z" fill={C.paper} />}
    <path d="M1 2H3V3H1Z" fill={C.paper} opacity={0.5 * progress} />
  </svg>
);
export const Burst = ({
  x,
  y,
  size = 180,
  color = C.yellow,
  rotate = 0,
}: {
  x: number;
  y: number;
  size?: number;
  color?: string;
  rotate?: number;
}) => (
  <svg
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: size,
      height: size,
      transform: `rotate(${rotate}deg)`,
    }}
    viewBox="0 0 100 100"
  >
    <path
      d="M50 0L61 28L85 10L77 39L100 50L73 61L90 87L62 77L50 100L39 72L12 90L23 62L0 50L28 39L10 12L39 23Z"
      fill={color}
    />
  </svg>
);
export const Sea = ({
  f,
  y = 660,
  color = C.blue,
  calm = false,
}: {
  f: number;
  y?: number;
  color?: string;
  calm?: boolean;
}) => (
  <svg
    style={{
      position: "absolute",
      left: 0,
      top: y,
      width: 1920,
      height: 1080 - y,
    }}
    viewBox={`0 0 1920 ${1080 - y}`}
    shapeRendering="crispEdges"
  >
    {[0, 1, 2, 3, 4].map((row) => (
      <path
        key={row}
        d={`M-100 ${row * 64} ${Array.from({ length: 40 }, (_, i) => `H${i * 60 + Math.round(Math.sin(f / (calm ? 70 : 20) + row) * 30)}V${row * 64 + (i % 2 ? 14 : 0)}`).join(" ")}V700H-100Z`}
        fill={row % 2 === 0 ? color : C.pale}
        opacity={row === 0 ? 1 : 0.4}
      />
    ))}
  </svg>
);
export const Caption = ({
  text,
  dark = false,
}: {
  text: string;
  dark?: boolean;
}) => {
  const words = useContext(WordContext);
  const f = useCurrentFrame();
  return (
    <div
      data-safe="caption"
      style={{
        position: "absolute",
        left: "50%",
        bottom: 94,
        transform: "translateX(-50%)",
        textAlign: "center",
        fontSize: 38,
        letterSpacing: 3,
        color: dark ? C.paper : C.ink,
        background: dark ? C.ink : C.paper,
        padding: "5px 18px",
        whiteSpace: "nowrap",
      }}
    >
      {words
        ? words.map((w, i) => (
            <span
              key={i}
              style={{
                color:
                  f >= (w.startMs / 1000) * 30 && f < (w.endMs / 1000) * 30
                    ? C.orange
                    : undefined,
              }}
            >
              {w.text}
            </span>
          ))
        : text}
    </div>
  );
};
