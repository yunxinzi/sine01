import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  useScene,
  SceneProps,
  Caption,
} from "../design";
export const Later = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const year = 2000 + Math.min(26, Math.floor(f / 3));
  return (
    <Stage words={p.words} chapter="03 / 时间继续走">
      <Text x={111} y={118} size={125}>
        直到后来
      </Text>
      <Text x={111} y={294} size={168} color={C.blue} delay={11}>
        我们都还在
      </Text>
      <Window
        x={134}
        y={589}
        w={1190}
        h={260}
        title="time.machine / RETAINED"
        bar={C.ink}
        scale={pop(f, 11)}
      >
        <Text x={40} y={19} size={141} color={C.ink} mode="none">
          {String(year)}
        </Text>
        <Label x={553} y={60} size={25}>
          2 MEMORIES / 2 PEOPLE
        </Label>
        <div
          style={{
            position: "absolute",
            left: 556,
            top: 107,
            width: 480,
            height: 22,
            border: `2px solid ${C.ink}`,
          }}
        >
          <div
            style={{
              width: `${Math.min(100, f)}%`,
              height: "100%",
              background: C.orange,
            }}
          />
        </div>
        <Label x={554} y={151} size={22}>
          {v % 2 ? "RESTORING..." : "AUTOSAVE ENABLED"}
        </Label>
      </Window>
      <Pixel x={1425} y={634 - Math.abs(Math.sin(f / 10)) * 15} size={188} />
      <Pixel x={1647} y={638} size={149} color={C.blue} />
      <Caption text={p.text ?? "直到后来我们都还在"} />
    </Stage>
  );
};
