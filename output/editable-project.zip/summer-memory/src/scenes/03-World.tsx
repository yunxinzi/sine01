import {
  C,
  Stage,
  Text,
  Stagger,
  Pixel,
  Window,
  Label,
  pop,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Burst,
} from "../design";
export const World = (p: SceneProps) => {
  const { f, v } = useScene(p);
  return (
    <Stage
      words={p.words}
      chapter="02 / 世界请注意"
      bg={v % 2 ? C.orange : C.paper}
    >
      <Text x={109} y={141} size={112}>
        很贪心
      </Text>
      <Text x={684} y={148} size={112} color={C.blue} delay={7}>
        要
      </Text>
      <Stagger text="全世界" x={97} y={304} size={258} delay={9} />
      <div
        style={{
          position: "absolute",
          left: 945,
          top: 318,
          width: 831,
          height: 282,
          background: C.blue,
          transform: `rotate(${-5 * pop(f, wordFrame(p, "注", 25))}deg) scale(${Math.max(0.001, pop(f, wordFrame(p, "注", 25)))})`,
          boxShadow: `10px 12px 0 ${C.ink}`,
        }}
      >
        <Text x={76} y={14} size={221} color={C.paper} mode="none">
          注意！
        </Text>
      </div>
      <Window
        x={203}
        y={696}
        w={875}
        h={156}
        title="broadcast.exe"
        scale={pop(f, 29)}
        bar={C.ink}
      >
        <Label x={29} y={20} size={27}>
          HELLO WORLD. WE ARE IN LOVE.
        </Label>
      </Window>
      <Burst x={1322} y={651} size={218} rotate={f / 2} />
      <Pixel
        x={1380}
        y={710 - Math.abs(Math.sin(f / 6)) * 33}
        size={159}
        mood="wink"
      />
      <Pixel x={1670} y={738} size={119} color={C.blue} mood="happy" />
      <Caption text={p.text ?? "很贪心 要全世界注意"} />
    </Stage>
  );
};
