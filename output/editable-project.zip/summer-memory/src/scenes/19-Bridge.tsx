import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  SceneProps,
  Caption,
  Cursor,
} from "../design";
export const Effort = (p: SceneProps) => {
  const { f } = useScene(p);
  return (
    <Stage words={p.words} chapter="05 / 还记得一起努力" bg={C.pale}>
      <Text x={110} y={129} size={122}>
        还记得
      </Text>
      <Text x={105} y={310} size={206} delay={12}>
        一起努力
      </Text>
      <Window
        x={1225}
        y={188}
        w={458}
        h={565}
        title="project / US"
        bar={C.ink}
        scale={pop(f, 8)}
      >
        <Label x={33} y={29} size={24}>
          SHARED PROGRESS
        </Label>
        {Array.from({ length: 5 }, (_, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 37,
              top: 105 + i * 67,
              height: 26,
              width: 375,
              background: C.gray,
            }}
          >
            <div
              style={{
                height: 26,
                width: 375 * clamp(f, i * 15, i * 15 + 35, 0, 1),
                background: i % 2 ? C.orange : C.blue,
              }}
            />
          </div>
        ))}
      </Window>
      <Pixel
        x={199 + clamp(f, 0, 90, 0, 400)}
        y={719}
        size={179}
        walk={f / 7}
      />
      <Pixel
        x={511 + clamp(f, 0, 90, 0, 380)}
        y={721}
        size={173}
        color={C.blue}
        walk={f / 7}
      />
      <Caption text={p.text ?? "还记得一起努力"} />
    </Stage>
  );
};
export const Promise = (p: SceneProps) => {
  const { f } = useScene(p);
  return (
    <Stage words={p.words} chapter="05 / 一言为定">
      <Text x={110} y={134} size={128}>
        还有那些
      </Text>
      <Text x={105} y={305} size={244} color={C.blue} delay={10} mode="slam">
        一言为定
      </Text>
      <Window
        x={212}
        y={638}
        w={995}
        h={216}
        title="promise.txt / READ ONLY"
        bar={C.ink}
        scale={pop(f, 10)}
      >
        <Label x={43} y={31} size={26}>
          SIGNATURE_A: SUMMER
        </Label>
        <Label x={43} y={83} size={26}>
          SIGNATURE_B: FOREVER
        </Label>
      </Window>
      <Pixel x={1399} y={614} size={167} mood="wink" />
      <div
        style={{
          position: "absolute",
          left: 1537,
          top: 344,
          width: 170,
          height: 170,
          border: `8px solid ${C.orange}`,
          borderRadius: "50%",
          transform: `rotate(-16deg) scale(${Math.max(0.001, pop(f, 24))})`,
          color: C.orange,
          fontFamily: "MemoryMono",
          fontSize: 37,
          textAlign: "center",
          paddingTop: 39,
          boxSizing: "border-box",
        }}
      >
        SAVED
      </div>
      <Caption text={p.text ?? "还有那些 一言为定"} />
    </Stage>
  );
};
export const Learning = (p: SceneProps) => {
  const { f } = useScene(p);
  return (
    <Stage words={p.words} chapter="05 / 把过去当成学习" bg={C.blue} dark>
      <Text x={110} y={128} size={101} color={C.paper}>
        现在我就当
      </Text>
      <Text x={105} y={281} size={224} color={C.orange} delay={9}>
        过去
      </Text>
      <Text x={673} y={306} size={123} color={C.paper} delay={16}>
        是种
      </Text>
      <Text x={1080} y={441} size={220} color={C.paper} delay={23}>
        学习
      </Text>
      <Window
        x={158}
        y={641}
        w={853}
        h={183}
        title="learning.exe / COMPLETE"
        bar={C.ink}
        scale={pop(f, 20)}
      >
        <Label x={38} y={28} size={28}>
          EXPERIENCE + 1
        </Label>
        <Label x={38} y={77} size={23}>
          YOUR HEART HAS BEEN UPDATED.
        </Label>
      </Window>
      <Pixel x={1473} y={737} size={142} />
      <Caption text={p.text ?? "现在我就当过去是种学习"} dark />
    </Stage>
  );
};
export const Difficult = (p: SceneProps) => {
  const { f } = useScene(p);
  return (
    <Stage words={p.words} chapter="05 / 虽然好不容易" bg={C.ink} dark>
      <Text x={110} y={137} size={130} color={C.paper}>
        虽然
      </Text>
      <Text x={110} y={335} size={231} color={C.orange} delay={12}>
        好不容易
      </Text>
      <Window
        x={1261}
        y={213}
        w={418}
        h={471}
        title="continue?"
        bar={C.blue}
        scale={pop(f, 5)}
      >
        <Pixel x={113} y={59} size={185} mood="sad" />
        <div
          style={{
            position: "absolute",
            left: 64,
            top: 316,
            width: 286,
            height: 62,
            border: `3px solid ${C.ink}`,
            fontSize: 35,
            color: C.ink,
            textAlign: "center",
          }}
        >
          继续
        </div>
      </Window>
      <Cursor x={1505} y={clamp(f, 0, 70, 810, 611)} click={f > 70 && f < 78} />
      <Label x={114} y={770} size={29} color={C.gray}>
        IT WAS HARD. WE KEPT GOING.
      </Label>
      <Caption text={p.text ?? "虽然好不容易"} dark />
    </Stage>
  );
};
