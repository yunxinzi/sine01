import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Burst,
} from "../design";
export const Impact = (p: SceneProps) => {
  const { f } = useScene(p);
  const contact = wordFrame(p, "惊", 18) + 3;
  const shock =
    f >= contact
      ? Math.sin((f - contact) * 2.6) * 22 * Math.exp(-(f - contact) / 15)
      : 0;
  return (
    <Stage
      words={p.words}
      bg={f >= 18 && f < 21 ? C.orange : C.paper}
      chapter="02 / 惊天动地"
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          transform: `translate(${shock}px,${shock * 0.45}px)`,
        }}
      >
        <Text x={112} y={126} size={117}>
          一碰就
        </Text>
        <div
          style={{
            position: "absolute",
            left: 100,
            top: 327,
            transform: `translateX(${clamp(f, 0, contact, -1100, 0)}px)`,
            filter: f > contact - 9 && f < contact ? "blur(2px)" : undefined,
          }}
        >
          <Text x={0} y={0} size={270} color={C.blue} mode="none">
            惊天
          </Text>
        </div>
        <div
          style={{
            position: "absolute",
            left: 1171,
            top: 327,
            transform: `translateX(${clamp(f, 0, contact, 1100, 0)}px)`,
            filter: f > contact - 9 && f < contact ? "blur(2px)" : undefined,
          }}
        >
          <Text x={0} y={0} size={270} color={C.ink} mode="none">
            动地
          </Text>
        </div>
        <Burst
          x={794}
          y={322}
          size={332 * pop(f, contact)}
          color={C.orange}
          rotate={f * 1.2}
        />
        <Pixel
          x={874}
          y={428 - Math.abs(Math.sin((f - contact) / 9)) * 100}
          size={158}
          mood="shock"
          angle={shock}
        />
        {Array.from({ length: 4 }, (_, i) => (
          <Window
            key={i}
            x={1080 + i * 114}
            y={707 - i * 37}
            w={230}
            h={116}
            title="震动"
            bar={i % 2 ? C.orange : C.blue}
            scale={pop(f, 24 + i * 4)}
            rotate={shock / 3}
          >
            <Label x={17} y={12} size={24}>
              !!!
            </Label>
          </Window>
        ))}
        <Label x={118} y={748} size={27}>
          COLLISION DETECTED / LOVE AT FULL VOLUME
        </Label>
      </div>
      <Caption text={p.text ?? "一碰就惊天动地"} />
    </Stage>
  );
};
