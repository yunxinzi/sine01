import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  SceneProps,
  Sea,
  Heart,
  Cursor,
} from "../design";
import analysis from "../audio-analysis.json";
export const Opening = (p: SceneProps) => {
  const { f } = useScene(p);
  const boot = f < 110;
  const energy =
    analysis.energy[Math.max(0, Math.min(analysis.energy.length - 1, f))] ?? 0;
  return (
    <Stage
      words={p.words}
      bg={boot ? C.ink : C.paper}
      dark={boot}
      chapter="00 / 读取夏天"
      texture={!boot}
    >
      {boot ? (
        <>
          <Label x={113} y={132} size={27} color={C.paper}>
            memory_system v.2007
          </Label>
          <Label x={114} y={214} size={31} color={C.orange}>
            &gt; load summer.exe
          </Label>
          <Text x={108} y={336} size={154} color={C.paper} delay={9}>
            正在读取夏天
          </Text>
          <Pixel x={1287} y={626 - energy * 48} size={237} mood="sleep" />
          <div
            style={{
              position: "absolute",
              left: 117,
              top: 642,
              width: 992,
              height: 42,
              border: `3px solid ${C.paper}`,
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${clamp(f, 0, 103, 0, 100)}%`,
                background: C.orange,
              }}
            />
          </div>
          <Label x={118} y={738} size={29} color={C.gray}>
            01 encounter / 02 love / 03 sea / 04 winter / 05 memory
          </Label>
        </>
      ) : (
        <>
          <Label x={114} y={134} size={28}>
            A KINETIC MEMORY FILM
          </Label>
          <Text x={108} y={209} size={230} color={C.ink} delay={110}>
            那年夏天
          </Text>
          <Text x={102} y={463} size={244} color={C.blue} delay={120}>
            宁静的海
          </Text>
          <Window
            x={1390}
            y={177}
            w={353}
            h={480}
            title="summer.exe"
            bar={C.orange}
            scale={pop(f, 132)}
            rotate={-4}
          >
            <Pixel x={54} y={80 - Math.sin(f / 25) * 8} size={239} />
            <Label x={59} y={349} size={23}>
              MEMORY: ONLINE
            </Label>
          </Window>
          <Label x={119} y={810} size={29}>
            王心凌 / 那年夏天宁静的海
          </Label>
          <Sea f={f} y={869} calm />
          {f > 300 && (
            <Pixel
              x={118 + clamp(f, 300, 570, 0, 540)}
              y={740 - Math.abs(Math.sin(f / 8)) * 12}
              size={98}
              walk={f / 6}
            />
          )}
          {f > 345 && (
            <Pixel
              x={1210 - clamp(f, 345, 570, 0, 380)}
              y={756 - Math.abs(Math.cos(f / 8)) * 12}
              size={91}
              color={C.blue}
              walk={f / 6}
            />
          )}
          {f > 415 && (
            <Window
              x={1391}
              y={707}
              w={353}
              h={171}
              title="start / READY"
              bar={C.blue}
              scale={pop(f, 415)}
            >
              <Text x={55} y={23} size={50} mode="none">
                打开夏天
              </Text>
            </Window>
          )}
          {f > 450 && (
            <Cursor
              x={clamp(f, 450, 577, 1220, 1570)}
              y={clamp(f, 450, 577, 941, 798)}
              click={f > 577 && f < 584}
            />
          )}
        </>
      )}
    </Stage>
  );
};
export const Interlude = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const q = (f / 150) % 1;
  const energy =
    analysis.energy[
      Math.max(
        0,
        Math.min(
          analysis.energy.length - 1,
          Math.floor((p.start ?? 0) * 30 + f),
        ),
      )
    ] ?? 0;
  return (
    <Stage words={p.words} bg={C.ink} dark chapter="03 / 记忆重播">
      <Text x={111} y={122} size={131} color={C.paper}>
        记忆正在
      </Text>
      <Text x={104} y={278} size={270} color={C.orange} delay={8}>
        重播
      </Text>
      <Label x={121} y={631} size={28} color={C.pale}>
        REWIND THE SUMMER / KEEP THE FEELING
      </Label>
      <Window
        x={1075}
        y={140}
        w={642}
        h={611}
        title="tape.deck / SIDE B"
        bar={C.blue}
        scale={pop(f, 6)}
      >
        <div
          style={{
            position: "absolute",
            left: 43,
            top: 51,
            width: 544,
            height: 227,
            border: `5px solid ${C.ink}`,
            borderRadius: 18,
            background: C.pale,
          }}
        >
          {[0, 1].map((i) => (
            <svg
              key={i}
              style={{
                position: "absolute",
                left: 52 + i * 299,
                top: 38,
                width: 137,
                height: 137,
                transform: `rotate(${f * (i ? 1 : -1) * 3}deg)`,
              }}
              viewBox="0 0 100 100"
            >
              <circle cx="50" cy="50" r="46" fill={C.ink} />
              <circle cx="50" cy="50" r="23" fill={C.paper} />
              {[0, 60, 120, 180, 240, 300].map((a) => (
                <rect
                  key={a}
                  x="47"
                  y="17"
                  width="6"
                  height="20"
                  fill={C.gray}
                  transform={`rotate(${a},50,50)`}
                />
              ))}
            </svg>
          ))}
          <div
            style={{
              position: "absolute",
              left: 222,
              top: 97,
              width: 92,
              height: 28,
              background: C.ink,
            }}
          />
        </div>
        <Pixel x={86 + q * 328} y={337 - energy * 40} size={158} walk={f / 6} />
        <Pixel
          x={409 - q * 328}
          y={347}
          size={151}
          color={C.blue}
          walk={f / 6}
        />
        <Label x={58} y={512} size={26}>
          {v % 2 ? "ONE MORE TIME." : "THE SAME SONG. A NEW MEMORY."}
        </Label>
      </Window>
    </Stage>
  );
};
export const Ending = (p: SceneProps) => {
  const { f, d } = useScene(p);
  const fold = clamp(f, d - 75, d - 40, 0, 1);
  return (
    <Stage words={p.words} chapter="05 / 回忆保存完成" bg={C.paper}>
      <div style={{ opacity: 1 - fold }}>
        <Label x={114} y={132} size={29}>
          THE SUMMER IS SAVED.
        </Label>
        <Text x={108} y={219} size={206}>
          回忆
        </Text>
        <Text x={104} y={439} size={222} color={C.blue} delay={8}>
          你真是精彩
        </Text>
        <Pixel
          x={1343}
          y={205 + Math.sin(f / 30) * 9}
          size={205}
          mood="happy"
        />
        <Heart x={1584} y={263} size={118} />
        <Sea f={f} y={771} calm />
      </div>
      <div style={{ opacity: fold }}>
        <Window
          x={617}
          y={333}
          w={681}
          h={353}
          title="memory.saved"
          bar={C.blue}
        >
          <Pixel x={40} y={59} size={149} mood="wink" />
          <Text x={220} y={60} size={74} mode="none">
            夏天已保存
          </Text>
          <Label x={226} y={172} size={21}>
            KEEP THE GOOD PARTS.
          </Label>
        </Window>
      </div>
    </Stage>
  );
};
