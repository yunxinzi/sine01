import {
  C,
  Stage,
  Text,
  Stagger,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  SceneProps,
  Caption,
} from "../design";
export const Young = (p: SceneProps) => {
  const { f, v } = useScene(p);
  return (
    <Stage words={p.words} bg={C.ink} dark chapter="02 / 只是太年轻">
      <Label x={118} y={120} size={29} color={C.orange}>
        WARNING: EXPERIENCE NOT INSTALLED
      </Label>
      <Text x={114} y={204} size={126} color={C.paper}>
        只是太
      </Text>
      <Stagger
        text="年轻"
        x={112}
        y={339}
        size={340}
        color={C.orange}
        delay={9}
        gap={8}
        mode="slam"
      />
      <Window
        x={1080}
        y={237}
        w={602}
        h={521}
        title="youth / beta version"
        bar={C.orange}
        scale={pop(f, 7)}
        rotate={-3}
      >
        <Pixel x={65} y={72} size={207} mood={f > 40 ? "shock" : "happy"} />
        <Pixel x={311} y={107} size={189} color={C.blue} />
        <div
          style={{
            position: "absolute",
            left: 48,
            right: 48,
            bottom: 79,
            height: 30,
            border: `3px solid ${C.ink}`,
          }}
        >
          <div
            style={{
              height: "100%",
              width: `${clamp(f, 10, 80, 0, 100)}%`,
              background: C.blue,
            }}
          />
        </div>
        <Label x={48} y={387} size={21}>
          GROWING UP... {Math.round(clamp(f, 10, 80, 0, 100))}%
        </Label>
      </Window>
      <Caption text={p.text ?? "只是太年轻"} dark />
      <Label x={115} y={813} size={28} color={C.gray}>
        {v % 2 ? "VERSION 02 / REPLAY" : "VERSION 01 / FIRST LOVE"}
      </Label>
    </Stage>
  );
};
