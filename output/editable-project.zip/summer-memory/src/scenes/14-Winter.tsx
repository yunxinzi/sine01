import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Cursor,
} from "../design";
export const Winter = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const gone = clamp(
    f,
    wordFrame(p, "不", 29),
    wordFrame(p, "不", 29) + 8,
    1,
    0,
  );
  return (
    <Stage words={p.words} bg={C.ink} dark chapter="04 / 冬天离别">
      {Array.from({ length: 35 }, (_, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: ((i * 139 + 83) % 1820) + 48,
            top: ((i * 59 + f * (0.8 + (i % 4) * 0.17)) % 850) + 80,
            width: 4 + (i % 3) * 3,
            height: 4 + (i % 3) * 3,
            background: C.paper,
            opacity: 0.13,
          }}
        />
      ))}
      <Text x={111} y={120} size={118} color={C.paper}>
        今年冬天
      </Text>
      <Text x={110} y={297} size={172} color={C.paper} delay={10}>
        你已经
      </Text>
      <Text x={677} y={293} size={228} color={C.orange} delay={29} mode="slam">
        不在
      </Text>
      <Pixel x={298} y={689} size={217} mood="sad" />
      <Pixel
        x={780}
        y={692}
        size={200}
        color={C.blue}
        opacity={gone}
        mood="sleep"
      />
      {f > wordFrame(p, "不", 38) && (
        <Window
          x={1165}
          y={359}
          w={550}
          h={378}
          title={v % 2 ? "memory / disconnected" : "memory / file missing"}
          bar={C.blue}
          scale={pop(f, wordFrame(p, "不", 38))}
        >
          <Label x={34} y={29} size={24}>
            PERSON_NOT_FOUND
          </Label>
          <Text x={33} y={83} size={137} color={C.blue} mode="none">
            404
          </Text>
          <Label x={34} y={251} size={24}>
            RETURN TO MEMORY
          </Label>
        </Window>
      )}
      <Cursor x={1625} y={794} click={f % 90 > 70 && f % 90 < 78} />
      <Caption text={p.text ?? "今年冬天你已经不在"} dark />
    </Stage>
  );
};
