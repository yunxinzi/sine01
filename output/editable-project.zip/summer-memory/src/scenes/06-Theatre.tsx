import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
} from "../design";
export const Theatre = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const curtain = clamp(f, 0, wordFrame(p, "演", 26), 0, 1);
  return (
    <Stage words={p.words} bg={C.ink} dark chapter="02 / 青春剧场">
      <Window
        x={159}
        y={141}
        w={1600}
        h={720}
        title="theatre.exe — TAKE 01"
        bar={C.blue}
      >
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: 1600,
            height: 668,
            background: C.paper,
          }}
        />
        <Text x={125} y={50} size={129}>
          都像在
        </Text>
        <Text x={705} y={48} size={282} color={C.blue} delay={8} mode="slam">
          演戏
        </Text>
        <Label x={119} y={274} size={30}>
          ACTION!
        </Label>
        <Label x={1207} y={486} size={23}>
          REC ●
        </Label>
        <Pixel
          x={470 + Math.sin(f / 17) * 50}
          y={388 - Math.abs(Math.sin(f / 7)) * 28}
          size={226}
          mood={v % 2 ? "shock" : "happy"}
          angle={Math.sin(f / 12) * 8}
        />
        <Pixel
          x={846 - Math.sin(f / 17) * 50}
          y={389}
          size={226}
          color={C.blue}
          mood="wink"
        />
        {[0, 1].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: i === 0 ? -curtain * 720 : 800 + curtain * 720,
              top: 0,
              width: 810,
              height: 668,
              background: C.orange,
              backgroundImage: `repeating-linear-gradient(90deg,transparent 0 40px,rgba(0,0,0,.12) 42px 47px)`,
              boxShadow: `3px 0 0 ${C.ink}`,
            }}
          />
        ))}
      </Window>
      <Caption text={p.text ?? "都像在演戏"} dark />
    </Stage>
  );
};
