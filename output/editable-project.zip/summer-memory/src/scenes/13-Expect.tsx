import {
  C,
  Stage,
  Text,
  Stagger,
  Pixel,
  Label,
  useScene,
  SceneProps,
  Caption,
  Burst,
  pop,
} from "../design";
export const Expect = (p: SceneProps) => {
  const { f } = useScene(p);
  return (
    <Stage words={p.words} bg={C.orange} chapter="03 / 充满期待">
      <Text x={112} y={129} size={111}>
        对这个世界
      </Text>
      <Text x={105} y={304} size={170} delay={8}>
        充满
      </Text>
      <Stagger
        text="期待"
        x={660}
        y={284}
        size={330}
        color={C.paper}
        delay={18}
        mode="slam"
        gap={6}
      />
      <Burst x={1461} y={161} size={222} color={C.blue} rotate={f * 0.9} />
      <div
        style={{
          position: "absolute",
          left: 1610,
          top: 714,
          transform: `scale(${Math.max(0.001, pop(f, 20))})`,
        }}
      >
        <svg width="120" height="150" viewBox="0 0 120 150">
          <path d="M0 0L110 70H55L32 134Z" fill={C.blue} />
        </svg>
      </div>
      <Pixel
        x={251}
        y={674 - Math.abs(Math.sin(f / 7)) * 49}
        size={191}
        color={C.paper}
      />
      <Pixel
        x={530}
        y={679 - Math.abs(Math.cos(f / 7)) * 49}
        size={183}
        color={C.blue}
      />
      <Label x={849} y={751} size={30}>
        THE FUTURE IS STILL OPEN. ↗
      </Label>
      <Caption text={p.text ?? "对这个世界充满期待"} />
    </Stage>
  );
};
