import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Heart,
} from "../design";
export const MissingHeart = (p: SceneProps) => {
  const { f } = useScene(p);
  const q = clamp(f, wordFrame(p, "空", 20), wordFrame(p, "块", 66), 0, 1);
  return (
    <Stage words={p.words} chapter="04 / 空出了一块">
      <Text x={109} y={134} size={123}>
        我的心
      </Text>
      <Text x={105} y={302} size={177} delay={12}>
        空出了一块
      </Text>
      <Heart x={1250} y={236} size={413} missing color={C.orange} />
      <svg
        style={{
          position: "absolute",
          left: 1250 + 225 + q * 144,
          top: 236 + 113 - q * 139,
          width: 413,
          height: 413,
          transform: `rotate(${q * 22}deg)`,
          opacity: 1 - q * 0.62,
        }}
        viewBox="0 0 11 11"
        shapeRendering="crispEdges"
      >
        <path d="M0 0H3V3H2V4H0Z" fill={C.orange} />
      </svg>
      <Window
        x={176}
        y={646}
        w={872}
        h={175}
        title="heart.storage"
        bar={C.ink}
        scale={pop(f, 15)}
      >
        <Label x={28} y={24} size={25}>
          AVAILABLE SPACE:
        </Label>
        <Text x={459} y={0} size={85} color={C.blue} mode="none">
          1 块
        </Text>
      </Window>
      <Pixel x={1379} y={725} size={126} mood="sad" />
      <Caption text={p.text ?? "我的心空出了一块"} />
    </Stage>
  );
};
