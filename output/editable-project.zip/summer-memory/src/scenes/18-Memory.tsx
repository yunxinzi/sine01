import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Sea,
  Heart,
} from "../design";
export const Memory = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const n = Math.min(
    4,
    Math.floor(Math.max(0, f - wordFrame(p, "你", 0)) / 13) + 1,
  );
  return (
    <Stage
      words={p.words}
      chapter="05 / 回忆真精彩"
      bg={v % 2 ? C.pale : C.paper}
    >
      <Text x={114} y={128} size={117}>
        回忆
      </Text>
      <Text x={483} y={129} size={117} delay={9}>
        你真是
      </Text>
      <Text x={99} y={314} size={270} color={C.blue} delay={19} mode="slam">
        精彩
      </Text>
      {Array.from({ length: n }, (_, i) => (
        <Window
          key={i}
          x={1036 + i * 74}
          y={147 + i * 144}
          w={538}
          h={256}
          title={
            [
              "01 / 青春相遇",
              "02 / 热烈相爱",
              "03 / 宁静的海",
              "04 / 感谢相遇",
            ][i]
          }
          bar={i % 2 ? C.blue : C.orange}
          scale={pop(f, i * 13)}
          rotate={(i - 1.5) * 3}
        >
          {i === 2 ? (
            <>
              <Sea f={f} y={120} />
              <Pixel x={95} y={35} size={105} />
              <Pixel x={291} y={39} size={103} color={C.blue} />
            </>
          ) : i === 1 ? (
            <>
              <Heart x={188} y={24} size={110} />
              <Pixel x={42} y={70} size={106} />
              <Pixel x={352} y={71} size={106} color={C.blue} />
            </>
          ) : (
            <>
              <Pixel x={i === 3 ? 224 : 119} y={52} size={139} />
              {i === 0 && <Pixel x={321} y={49} size={129} color={C.blue} />}
            </>
          )}
        </Window>
      ))}
      <Label x={116} y={681} size={26}>
        DO NOT DELETE THE SUMMER.
      </Label>
      <Pixel x={194} y={753} size={135} mood="happy" />
      <Caption text={p.text ?? "回忆 你真是精彩"} />
    </Stage>
  );
};
