import {
  C,
  Stage,
  Text,
  Stagger,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
} from "../design";
export const Calendar = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const close = clamp(f, 0, wordFrame(p, "在", 65), 0, 1);
  const day = 1 + (Math.floor(f / 7) % 30);
  return (
    <Stage
      words={p.words}
      chapter="01 / 青春相遇"
      bg={v % 2 ? C.pale : C.paper}
    >
      <Text x={110} y={138} size={118}>
        那时我们
      </Text>
      <Stagger text="天天" x={94} y={281} size={270} />
      <div
        style={{
          position: "absolute",
          left: 125,
          top: 624,
          width: 619,
          height: 122,
          background: C.blue,
          transform: `rotate(${-3 + pop(f, 24) * 3}deg) scale(${Math.max(0.001, pop(f, 24))})`,
        }}
      >
        <Text x={39} y={-7} size={108} color={C.paper} mode="none">
          在一起
        </Text>
      </div>
      <Window
        x={1005}
        y={169}
        w={650}
        h={554}
        title="calendar / DAYS TOGETHER"
        scale={pop(f, 3)}
      >
        <Label x={34} y={26} size={24}>
          SUMMER — {String(day).padStart(2, "0")} / 30
        </Label>
        <Text x={45} y={68} size={252} color={C.blue} mode="none">
          {String(day).padStart(2, "0")}
        </Text>
        <div
          style={{
            position: "absolute",
            bottom: 30,
            left: 30,
            right: 30,
            display: "flex",
            gap: 15,
          }}
        >
          {Array.from({ length: 7 }, (_, i) => (
            <div
              key={i}
              style={{
                height: 12,
                flex: 1,
                background: i < (f / 12) % 7 ? C.orange : C.gray,
              }}
            />
          ))}
        </div>
      </Window>
      <Pixel
        x={950 + close * 195}
        y={754 - Math.abs(Math.sin(f / 6)) * 15}
        size={170}
        walk={f / 5}
      />
      <Pixel
        x={1580 - close * 195}
        y={754 - Math.abs(Math.cos(f / 6)) * 15}
        size={170}
        color={C.blue}
        walk={f / 5}
      />
      <Caption text={p.text ?? "那时我们天天在一起"} />
    </Stage>
  );
};
