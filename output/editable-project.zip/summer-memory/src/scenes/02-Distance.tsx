import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Cursor,
} from "../design";
export const Distance = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const q = clamp(f, wordFrame(p, "不", 5), wordFrame(p, "距", 62), 0, 1);
  const dist = Math.round(999 * (1 - q));
  return (
    <Stage words={p.words} bg={C.blue} dark chapter="02 / 热烈相爱">
      <Text x={102} y={129} size={116} color={C.paper}>
        太幸福到
      </Text>
      <Text x={96} y={278} size={237} color={C.paper} delay={7}>
        不需要
      </Text>
      <Text
        x={920}
        y={272}
        size={250}
        color={C.orange}
        mode="slam"
        delay={14}
        shadow
      >
        距离
      </Text>
      <Window
        x={525}
        y={618}
        w={870}
        h={205}
        title="distance.monitor"
        bar={C.ink}
        scale={pop(f, 15)}
      >
        <Label x={42} y={24} size={25}>
          DISTANCE
        </Label>
        <Text x={364} y={3} size={101} color={C.blue} mode="none">
          {dist === 0 ? "0" : String(dist).padStart(3, "0")}
        </Text>
        <Label x={695} y={77} size={32}>
          px
        </Label>
      </Window>
      <Pixel
        x={155 + q * 105}
        y={655 + Math.sin(f / 10) * 8}
        size={195}
        walk={f / 4}
      />
      <Pixel
        x={1555 - q * 105}
        y={655 + Math.cos(f / 10) * 8}
        size={195}
        color={C.paper}
        walk={f / 4}
      />
      <div
        style={{
          position: "absolute",
          left: 155 + q * 105 + 202,
          top: 730,
          width: 1175 - q * 210,
          height: 0,
          borderTop: `3px dashed ${C.paper}`,
          opacity: 0.55,
        }}
      />
      <Cursor
        x={1390 - clamp(f, 45, 80, 0, 160)}
        y={850 - clamp(f, 45, 80, 0, 60)}
        click={f > 79 && f < 87}
      />
      <Caption text={p.text ?? "太幸福到不需要距离"} dark />
      <Label x={1400} y={119} color={C.paper} size={24}>
        {v % 2 ? "RECONNECTED" : "NO SPACE BETWEEN US"}
      </Label>
    </Stage>
  );
};
