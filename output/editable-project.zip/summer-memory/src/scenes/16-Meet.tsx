import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  useScene,
  SceneProps,
  Caption,
  Burst,
} from "../design";
export const Meet = (p: SceneProps) => {
  const { f, v } = useScene(p);
  return (
    <Stage words={p.words} bg={C.blue} dark chapter="05 / 感谢相遇">
      <Text x={111} y={136} size={162} color={C.paper}>
        很高兴
      </Text>
      <Text x={111} y={335} size={237} color={C.orange} delay={12}>
        遇见你
      </Text>
      <Window
        x={1160}
        y={178}
        w={563}
        h={639}
        title="memory.restore / THANK YOU"
        bar={C.ink}
        scale={pop(f, 9)}
        rotate={-3}
      >
        <Burst x={112} y={58} size={322} color={C.yellow} rotate={f * 0.3} />
        <Pixel
          x={148}
          y={127 - Math.abs(Math.sin(f / 14)) * 12}
          size={247}
          mood="happy"
        />
        <Text x={64} y={407} size={62} color={C.ink} mode="none">
          很高兴遇见你
        </Text>
        <Label x={96} y={496} size={22}>
          MEMORY SAVED. {v % 2 ? "AGAIN." : "FOREVER."}
        </Label>
      </Window>
      <Label x={117} y={770} size={32} color={C.paper}>
        THANK YOU FOR THAT SUMMER.
      </Label>
      <Caption text={p.text ?? "很高兴遇见你"} dark />
    </Stage>
  );
};
