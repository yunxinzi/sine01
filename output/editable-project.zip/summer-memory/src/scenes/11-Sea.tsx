import {
  C,
  Stage,
  Text,
  Pixel,
  Label,
  useScene,
  SceneProps,
  Caption,
  Sea,
} from "../design";
export const QuietSea = (p: SceneProps) => {
  const { f, v } = useScene(p);
  return (
    <Stage
      words={p.words}
      bg={C.blue}
      dark
      chapter="03 / 宁静的海"
      texture={false}
    >
      <Label x={120} y={120} color={C.pale} size={25}>
        SOUND DOWN. MEMORY UP.
      </Label>
      <Text x={112} y={206} size={115} color={C.paper}>
        这一大片
      </Text>
      <Text x={99} y={353} size={235} color={C.paper} delay={8}>
        宁静的海
      </Text>
      <div
        style={{
          position: "absolute",
          left: 1334,
          top: 221,
          width: 193,
          height: 193,
          background: C.orange,
          borderRadius: "50%",
        }}
      />
      <Sea f={f} y={707} color={C.pale} calm />
      <div
        style={{
          position: "absolute",
          left: 1230,
          top: 650,
          width: 530,
          height: 15,
          background: C.ink,
        }}
      />
      <Pixel x={1285} y={521 + Math.sin(f / 32) * 5} size={154} mood="sleep" />
      <Pixel
        x={1507}
        y={530 + Math.cos(f / 32) * 5}
        size={145}
        color={v % 2 ? C.paper : C.orange}
        mood="sleep"
      />
      <Caption text={p.text ?? "这一大片宁静的海"} dark />
    </Stage>
  );
};
