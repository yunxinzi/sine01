import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  SceneProps,
  Caption,
  Cursor,
} from "../design";
export const Today = (p: SceneProps) => {
  const { f } = useScene(p);
  const q = clamp(f, 15, 65, 0, 1);
  return (
    <Stage words={p.words} chapter="03 / 今天看你" bg={C.pale}>
      <Text x={115} y={211} size={259}>
        今天
      </Text>
      <Text x={979} y={552} size={247} delay={22} color={C.blue}>
        看你
      </Text>
      <Window
        x={1074}
        y={124}
        w={557}
        h={414}
        title="profile / NOW"
        scale={pop(f, 8)}
        bar={C.ink}
      >
        <Pixel
          x={169}
          y={71}
          size={206}
          color={C.blue}
          mood="sleep"
          opacity={1 - q * 0.6}
        />
        <Label x={100} y={285} size={24}>
          LAST SEEN: YESTERDAY
        </Label>
      </Window>
      <Pixel x={359} y={666} size={237} mood="sad" />
      <div
        style={{
          position: "absolute",
          left: 645,
          top: 654,
          width: 272,
          height: 3,
          background: C.ink,
        }}
      />
      <Cursor x={999 + q * 135} y={653 - q * 173} />
      <Caption text={p.text ?? "今天 看你"} />
    </Stage>
  );
};
