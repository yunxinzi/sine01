import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  clamp,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Cursor,
} from "../design";
export const Understand = (p: SceneProps) => {
  const { f } = useScene(p);
  const q = clamp(f, wordFrame(p, "终", 15), wordFrame(p, "白", 70), 0, 1);
  return (
    <Stage words={p.words} chapter="05 / 终究明白">
      <Text x={109} y={126} size={129}>
        让我
      </Text>
      <Text x={110} y={294} size={209} delay={8}>
        终究
      </Text>
      <Text x={652} y={283} size={263} color={C.blue} delay={23}>
        明白
      </Text>
      <Window
        x={1203}
        y={198}
        w={460}
        h={515}
        title="system.update"
        bar={C.ink}
        scale={pop(f, 9)}
      >
        <svg
          style={{
            position: "absolute",
            left: 110,
            top: 71,
            width: 236,
            height: 224,
          }}
          viewBox="0 0 100 100"
        >
          <path
            d="M8 50L36 77L91 16"
            fill="none"
            stroke={C.orange}
            strokeWidth="16"
            strokeLinecap="square"
            strokeDasharray="150"
            strokeDashoffset={150 * (1 - q)}
          />
        </svg>
        <Text x={62} y={338} size={65} color={C.ink} mode="none">
          更新完成
        </Text>
      </Window>
      <Pixel x={306 + q * 206} y={701} size={168} walk={f / 6} />
      <Label x={803} y={763} size={27}>
        ACCEPT / KEEP THE GOOD PARTS
      </Label>
      <Cursor x={1550} y={795} click={f > 72 && f < 80} />
      <Caption text={p.text ?? "让我终究明白"} />
    </Stage>
  );
};
