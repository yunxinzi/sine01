import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  useScene,
  SceneProps,
  Caption,
  Cursor,
} from "../design";
export const Yesterday = (p: SceneProps) => {
  const { f, v } = useScene(p);
  const n = Math.min(4, 1 + Math.floor(f / 17));
  return (
    <Stage words={p.words} bg={C.ink} dark chapter="03 / 昨天去了哪里">
      <Text x={109} y={111} size={120} color={C.paper}>
        昨天的你
      </Text>
      <Text x={105} y={289} size={218} color={C.orange} delay={10}>
        去了哪里
      </Text>
      {Array.from({ length: n }, (_, i) => (
        <Window
          key={i}
          x={1000 + i * 100}
          y={171 + i * 115}
          w={489}
          h={266}
          title="search.memory"
          bar={i === n - 1 ? C.orange : C.blue}
          scale={pop(f, i * 17)}
          rotate={i % 2 ? 2 : -2}
        >
          <Label x={24} y={29} size={26}>
            SEARCHING YESTERDAY...
          </Label>
          <Text x={31} y={65} size={82} color={C.ink} mode="none">
            {i === n - 1 ? "在哪里？" : "404"}
          </Text>
          <Label x={29} y={165} size={21}>
            RESULT: {v % 2 ? "REPLAY INCOMPLETE" : "NOT FOUND"}
          </Label>
        </Window>
      ))}
      <Pixel x={218} y={656} size={194} mood="shock" />
      <Cursor x={1670} y={761} click={f % 40 < 8} />
      <Caption text={p.text ?? "昨天的你去了哪里"} dark />
    </Stage>
  );
};
