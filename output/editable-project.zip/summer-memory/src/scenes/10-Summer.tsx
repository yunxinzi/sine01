import {
  C,
  Stage,
  Text,
  Pixel,
  Window,
  Label,
  pop,
  useScene,
  wordFrame,
  SceneProps,
  Caption,
  Sea,
} from "../design";
export const Summer = (p: SceneProps) => {
  const { f, v } = useScene(p);
  return (
    <Stage words={p.words} chapter="03 / 夏天记忆" bg={C.paper}>
      <Text x={114} y={118} size={115}>
        那年
      </Text>
      <Text x={107} y={245} size={264} color={C.orange} delay={7}>
        夏天
      </Text>
      <Text x={932} y={267} size={139} color={C.blue} delay={18}>
        我和你
      </Text>
      <Text x={1095} y={448} size={131} delay={27}>
        躲在
      </Text>
      <div
        style={{
          position: "absolute",
          left: 1214,
          top: 148,
          width: 117,
          height: 117,
          borderRadius: "50%",
          background: C.yellow,
          transform: `scale(${Math.max(0.001, pop(f, 12))})`,
        }}
      />
      <Sea f={f} y={754} calm />
      <Window
        x={156}
        y={615}
        w={751}
        h={222}
        title={v % 2 ? "memory.restore / SUMMER" : "memory.save / SUMMER"}
        scale={pop(f, wordFrame(p, "躲", 26))}
        bar={C.ink}
      >
        <Pixel x={122} y={30} size={151} />
        <Pixel x={395} y={30} size={151} color={C.blue} />
        <Label x={283} y={66} size={25}>
          ＋
        </Label>
      </Window>
      <Caption text={p.text ?? "那年夏天我和你躲在"} />
    </Stage>
  );
};
