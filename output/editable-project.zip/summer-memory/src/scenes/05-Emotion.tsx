import {
  C,
  Stage,
  Text,
  Pixel,
  Label,
  pop,
  useScene,
  SceneProps,
  Caption,
  Heart,
} from "../design";
export const Emotion = (p: SceneProps) => {
  const { f } = useScene(p);
  const turn = f > 38;
  return (
    <Stage words={p.words} chapter="02 / 情绪切换">
      <div
        style={{
          position: "absolute",
          left: turn ? 940 : 1110,
          top: 54,
          bottom: 49,
          width: 1200,
          background: C.blue,
          transform: `skewX(-8deg)`,
        }}
      />
      <Text x={109} y={195} size={236}>
        快乐
      </Text>
      <Text x={896} y={292} size={106} delay={18}>
        和
      </Text>
      <Text x={1175} y={375} size={236} color={C.paper} delay={32} mode="slam">
        伤心
      </Text>
      <Label x={117} y={141} size={23}>
        HAPPY MODE / ON
      </Label>
      <Label x={1230} y={309} size={23} color={C.paper}>
        SAD MODE / ON
      </Label>
      <Heart x={368} y={548} size={125 * pop(f, 8)} color={C.orange} />
      <Pixel x={235} y={690 - Math.abs(Math.sin(f / 5)) * 52} size={248} />
      <Pixel x={1372} y={683} size={248} color={C.orange} mood="sad" />
      <Caption text={p.text ?? "快乐和伤心"} dark />
    </Stage>
  );
};
