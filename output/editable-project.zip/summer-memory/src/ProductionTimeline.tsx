import { AbsoluteFill, Sequence, useVideoConfig } from "remotion";
import {
  Calendar,
  Difficult,
  Distance,
  Effort,
  Emotion,
  Ending,
  Expect,
  Impact,
  Interlude,
  Later,
  Learning,
  Meet,
  Memory,
  MissingHeart,
  Opening,
  Promise,
  QuietSea,
  Summer,
  Theatre,
  Today,
  Understand,
  Winter,
  World,
  Yesterday,
  Young,
} from "./registry";
import { Soundtrack, Progress } from "./Film";
export const ProductionTimeline = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <Soundtrack />
      <Sequence name={"01 / Opening"} durationInFrames={606} premountFor={fps}>
        <Opening duration={606} start={0.0} variant={0} />
      </Sequence>
      <Sequence
        name={"02 / 那时我们天天在一起"}
        from={606}
        durationInFrames={121}
        premountFor={fps}
      >
        <Calendar
          duration={121}
          start={20.2}
          variant={0}
          text={"那时我们天天在一起"}
          words={[
            {
              text: "那",
              startMs: 0,
              endMs: 250,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "时",
              startMs: 250,
              endMs: 570,
              timestampMs: 250,
              confidence: null,
            },
            {
              text: "我",
              startMs: 570,
              endMs: 990,
              timestampMs: 570,
              confidence: null,
            },
            {
              text: "们",
              startMs: 990,
              endMs: 1370,
              timestampMs: 990,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1370,
              endMs: 1660,
              timestampMs: 1370,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1660,
              endMs: 2170,
              timestampMs: 1660,
              confidence: null,
            },
            {
              text: "在",
              startMs: 2170,
              endMs: 2730,
              timestampMs: 2170,
              confidence: null,
            },
            {
              text: "一",
              startMs: 2730,
              endMs: 3020,
              timestampMs: 2730,
              confidence: null,
            },
            {
              text: "起",
              startMs: 3020,
              endMs: 3650,
              timestampMs: 3020,
              confidence: null,
            },
          ]}
          accents={[9, 43, 52, 73, 92]}
        />
      </Sequence>
      <Sequence
        name={"03 / 太幸福到不需要距离"}
        from={727}
        durationInFrames={109}
        premountFor={fps}
      >
        <Distance
          duration={109}
          start={24.233333333333334}
          variant={0}
          text={"太幸福到不需要距离"}
          words={[
            {
              text: "太",
              startMs: 0,
              endMs: 210,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "幸",
              startMs: 210,
              endMs: 560,
              timestampMs: 210,
              confidence: null,
            },
            {
              text: "福",
              startMs: 560,
              endMs: 1060,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "到",
              startMs: 1060,
              endMs: 1300,
              timestampMs: 1060,
              confidence: null,
            },
            {
              text: "不",
              startMs: 1300,
              endMs: 1480,
              timestampMs: 1300,
              confidence: null,
            },
            {
              text: "需",
              startMs: 1480,
              endMs: 2140,
              timestampMs: 1480,
              confidence: null,
            },
            {
              text: "要",
              startMs: 2140,
              endMs: 2540,
              timestampMs: 2140,
              confidence: null,
            },
            {
              text: "距",
              startMs: 2540,
              endMs: 3080,
              timestampMs: 2540,
              confidence: null,
            },
            {
              text: "离",
              startMs: 3080,
              endMs: 3640,
              timestampMs: 3080,
              confidence: null,
            },
          ]}
          accents={[50, 79]}
        />
      </Sequence>
      <Sequence
        name={"04 / 很贪心要全世界注意"}
        from={836}
        durationInFrames={242}
        premountFor={fps}
      >
        <World
          duration={242}
          start={27.866666666666667}
          variant={0}
          text={"很贪心要全世界注意"}
          words={[
            {
              text: "很",
              startMs: 0,
              endMs: 1690,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "贪",
              startMs: 1690,
              endMs: 2150,
              timestampMs: 1690,
              confidence: null,
            },
            {
              text: "心",
              startMs: 2150,
              endMs: 3810,
              timestampMs: 2150,
              confidence: null,
            },
            {
              text: "要",
              startMs: 3810,
              endMs: 4300,
              timestampMs: 3810,
              confidence: null,
            },
            {
              text: "全",
              startMs: 4300,
              endMs: 4800,
              timestampMs: 4300,
              confidence: null,
            },
            {
              text: "世",
              startMs: 4800,
              endMs: 5150,
              timestampMs: 4800,
              confidence: null,
            },
            {
              text: "界",
              startMs: 5150,
              endMs: 5600,
              timestampMs: 5150,
              confidence: null,
            },
            {
              text: "注",
              startMs: 5600,
              endMs: 6510,
              timestampMs: 5600,
              confidence: null,
            },
            {
              text: "意",
              startMs: 6510,
              endMs: 7540,
              timestampMs: 6510,
              confidence: null,
            },
          ]}
          accents={[5, 67, 120, 133, 145, 157, 172]}
        />
      </Sequence>
      <Sequence
        name={"05 / 只是太年轻"}
        from={1078}
        durationInFrames={65}
        premountFor={fps}
      >
        <Young
          duration={65}
          start={35.93333333333333}
          variant={0}
          text={"只是太年轻"}
          words={[
            {
              text: "只",
              startMs: 0,
              endMs: 240,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "是",
              startMs: 240,
              endMs: 580,
              timestampMs: 240,
              confidence: null,
            },
            {
              text: "太",
              startMs: 580,
              endMs: 1110,
              timestampMs: 580,
              confidence: null,
            },
            {
              text: "年",
              startMs: 1110,
              endMs: 1630,
              timestampMs: 1110,
              confidence: null,
            },
            {
              text: "轻",
              startMs: 1630,
              endMs: 2160,
              timestampMs: 1630,
              confidence: null,
            },
          ]}
          accents={[22, 53]}
        />
      </Sequence>
      <Sequence
        name={"06 / 快乐和伤心"}
        from={1143}
        durationInFrames={65}
        premountFor={fps}
      >
        <Emotion
          duration={65}
          start={38.1}
          variant={0}
          text={"快乐和伤心"}
          words={[
            {
              text: "快",
              startMs: 0,
              endMs: 320,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "乐",
              startMs: 320,
              endMs: 530,
              timestampMs: 320,
              confidence: null,
            },
            {
              text: "和",
              startMs: 530,
              endMs: 970,
              timestampMs: 530,
              confidence: null,
            },
            {
              text: "伤",
              startMs: 970,
              endMs: 1570,
              timestampMs: 970,
              confidence: null,
            },
            {
              text: "心",
              startMs: 1570,
              endMs: 1910,
              timestampMs: 1570,
              confidence: null,
            },
          ]}
          accents={[37]}
        />
      </Sequence>
      <Sequence
        name={"07 / 都像在演戏"}
        from={1208}
        durationInFrames={66}
        premountFor={fps}
      >
        <Theatre
          duration={66}
          start={40.266666666666666}
          variant={0}
          text={"都像在演戏"}
          words={[
            {
              text: "都",
              startMs: 0,
              endMs: 190,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "像",
              startMs: 190,
              endMs: 500,
              timestampMs: 190,
              confidence: null,
            },
            {
              text: "在",
              startMs: 500,
              endMs: 830,
              timestampMs: 500,
              confidence: null,
            },
            {
              text: "演",
              startMs: 830,
              endMs: 1500,
              timestampMs: 830,
              confidence: null,
            },
            {
              text: "戏",
              startMs: 1500,
              endMs: 2220,
              timestampMs: 1500,
              confidence: null,
            },
          ]}
          accents={[7, 19, 53]}
        />
      </Sequence>
      <Sequence
        name={"08 / 一碰就惊天动地"}
        from={1274}
        durationInFrames={95}
        premountFor={fps}
      >
        <Impact
          duration={95}
          start={42.46666666666667}
          variant={0}
          text={"一碰就惊天动地"}
          words={[
            {
              text: "一",
              startMs: 0,
              endMs: 230,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "碰",
              startMs: 230,
              endMs: 480,
              timestampMs: 230,
              confidence: null,
            },
            {
              text: "就",
              startMs: 480,
              endMs: 730,
              timestampMs: 480,
              confidence: null,
            },
            {
              text: "惊",
              startMs: 730,
              endMs: 1020,
              timestampMs: 730,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1020,
              endMs: 1350,
              timestampMs: 1020,
              confidence: null,
            },
            {
              text: "动",
              startMs: 1350,
              endMs: 1880,
              timestampMs: 1350,
              confidence: null,
            },
            {
              text: "地",
              startMs: 1880,
              endMs: 2490,
              timestampMs: 1880,
              confidence: null,
            },
          ]}
          accents={[2, 16, 24, 33, 81]}
        />
      </Sequence>
      <Sequence
        name={"09 / 今天看你"}
        from={1369}
        durationInFrames={102}
        premountFor={fps}
      >
        <Today
          duration={102}
          start={45.63333333333333}
          variant={0}
          text={"今天看你"}
          words={[
            {
              text: "今",
              startMs: 0,
              endMs: 470,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "天",
              startMs: 470,
              endMs: 2080,
              timestampMs: 470,
              confidence: null,
            },
            {
              text: "看",
              startMs: 2080,
              endMs: 2460,
              timestampMs: 2080,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2460,
              endMs: 3170,
              timestampMs: 2460,
              confidence: null,
            },
          ]}
          accents={[2, 17, 51, 67, 83, 95]}
        />
      </Sequence>
      <Sequence
        name={"10 / 昨天的你去了哪里"}
        from={1471}
        durationInFrames={136}
        premountFor={fps}
      >
        <Yesterday
          duration={136}
          start={49.03333333333333}
          variant={0}
          text={"昨天的你去了哪里"}
          words={[
            {
              text: "昨",
              startMs: 0,
              endMs: 300,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "天",
              startMs: 300,
              endMs: 640,
              timestampMs: 300,
              confidence: null,
            },
            {
              text: "的",
              startMs: 640,
              endMs: 890,
              timestampMs: 640,
              confidence: null,
            },
            {
              text: "你",
              startMs: 890,
              endMs: 1150,
              timestampMs: 890,
              confidence: null,
            },
            {
              text: "去",
              startMs: 1150,
              endMs: 1450,
              timestampMs: 1150,
              confidence: null,
            },
            {
              text: "了",
              startMs: 1450,
              endMs: 1850,
              timestampMs: 1450,
              confidence: null,
            },
            {
              text: "哪",
              startMs: 1850,
              endMs: 2480,
              timestampMs: 1850,
              confidence: null,
            },
            {
              text: "里",
              startMs: 2480,
              endMs: 3870,
              timestampMs: 2480,
              confidence: null,
            },
          ]}
          accents={[3, 15, 36, 47, 63, 78]}
        />
      </Sequence>
      <Sequence
        name={"11 / 那年夏天我和你躲在"}
        from={1607}
        durationInFrames={124}
        premountFor={fps}
      >
        <Summer
          duration={124}
          start={53.56666666666667}
          variant={0}
          text={"那年夏天我和你躲在"}
          words={[
            {
              text: "那",
              startMs: 0,
              endMs: 600,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "年",
              startMs: 600,
              endMs: 1040,
              timestampMs: 600,
              confidence: null,
            },
            {
              text: "夏",
              startMs: 1040,
              endMs: 1700,
              timestampMs: 1040,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1700,
              endMs: 2170,
              timestampMs: 1700,
              confidence: null,
            },
            {
              text: "我",
              startMs: 2170,
              endMs: 2460,
              timestampMs: 2170,
              confidence: null,
            },
            {
              text: "和",
              startMs: 2460,
              endMs: 2770,
              timestampMs: 2460,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2770,
              endMs: 3090,
              timestampMs: 2770,
              confidence: null,
            },
            {
              text: "躲",
              startMs: 3090,
              endMs: 3310,
              timestampMs: 3090,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3310,
              endMs: 3830,
              timestampMs: 3310,
              confidence: null,
            },
          ]}
          accents={[6, 32, 40, 54, 95, 103]}
        />
      </Sequence>
      <Sequence
        name={"12 / 这一大片宁静的海"}
        from={1731}
        durationInFrames={135}
        premountFor={fps}
      >
        <QuietSea
          duration={135}
          start={57.7}
          variant={0}
          text={"这一大片宁静的海"}
          words={[
            {
              text: "这",
              startMs: 0,
              endMs: 290,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "一",
              startMs: 290,
              endMs: 550,
              timestampMs: 290,
              confidence: null,
            },
            {
              text: "大",
              startMs: 550,
              endMs: 790,
              timestampMs: 550,
              confidence: null,
            },
            {
              text: "片",
              startMs: 790,
              endMs: 1070,
              timestampMs: 790,
              confidence: null,
            },
            {
              text: "宁",
              startMs: 1070,
              endMs: 1340,
              timestampMs: 1070,
              confidence: null,
            },
            {
              text: "静",
              startMs: 1340,
              endMs: 1820,
              timestampMs: 1340,
              confidence: null,
            },
            {
              text: "的",
              startMs: 1820,
              endMs: 2340,
              timestampMs: 1820,
              confidence: null,
            },
            {
              text: "海",
              startMs: 2340,
              endMs: 3210,
              timestampMs: 2340,
              confidence: null,
            },
          ]}
          accents={[2, 19, 35, 42, 60, 91]}
        />
      </Sequence>
      <Sequence
        name={"13 / 直到后来我们都还在"}
        from={1866}
        durationInFrames={123}
        premountFor={fps}
      >
        <Later
          duration={123}
          start={62.2}
          variant={0}
          text={"直到后来我们都还在"}
          words={[
            {
              text: "直",
              startMs: 0,
              endMs: 570,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "到",
              startMs: 570,
              endMs: 1040,
              timestampMs: 570,
              confidence: null,
            },
            {
              text: "后",
              startMs: 1040,
              endMs: 1630,
              timestampMs: 1040,
              confidence: null,
            },
            {
              text: "来",
              startMs: 1630,
              endMs: 2180,
              timestampMs: 1630,
              confidence: null,
            },
            {
              text: "我",
              startMs: 2180,
              endMs: 2480,
              timestampMs: 2180,
              confidence: null,
            },
            {
              text: "们",
              startMs: 2480,
              endMs: 2720,
              timestampMs: 2480,
              confidence: null,
            },
            {
              text: "都",
              startMs: 2720,
              endMs: 2970,
              timestampMs: 2720,
              confidence: null,
            },
            {
              text: "还",
              startMs: 2970,
              endMs: 3560,
              timestampMs: 2970,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3560,
              endMs: 3900,
              timestampMs: 3560,
              confidence: null,
            },
          ]}
          accents={[3, 20, 34, 59, 69, 77, 84, 94, 110, 119]}
        />
      </Sequence>
      <Sequence
        name={"14 / 对这个世界充满期待"}
        from={1989}
        durationInFrames={134}
        premountFor={fps}
      >
        <Expect
          duration={134}
          start={66.3}
          variant={0}
          text={"对这个世界充满期待"}
          words={[
            {
              text: "对",
              startMs: 0,
              endMs: 240,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "这",
              startMs: 240,
              endMs: 530,
              timestampMs: 240,
              confidence: null,
            },
            {
              text: "个",
              startMs: 530,
              endMs: 720,
              timestampMs: 530,
              confidence: null,
            },
            {
              text: "世",
              startMs: 720,
              endMs: 1030,
              timestampMs: 720,
              confidence: null,
            },
            {
              text: "界",
              startMs: 1030,
              endMs: 1290,
              timestampMs: 1030,
              confidence: null,
            },
            {
              text: "充",
              startMs: 1290,
              endMs: 1800,
              timestampMs: 1290,
              confidence: null,
            },
            {
              text: "满",
              startMs: 1800,
              endMs: 2320,
              timestampMs: 1800,
              confidence: null,
            },
            {
              text: "期",
              startMs: 2320,
              endMs: 3480,
              timestampMs: 2320,
              confidence: null,
            },
            {
              text: "待",
              startMs: 3480,
              endMs: 4180,
              timestampMs: 3480,
              confidence: null,
            },
          ]}
          accents={[9, 18, 41, 59, 74, 99, 107, 117]}
        />
      </Sequence>
      <Sequence
        name={"15 / 今年冬天你已经不在"}
        from={2123}
        durationInFrames={123}
        premountFor={fps}
      >
        <Winter
          duration={123}
          start={70.76666666666667}
          variant={0}
          text={"今年冬天你已经不在"}
          words={[
            {
              text: "今",
              startMs: 0,
              endMs: 600,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "年",
              startMs: 600,
              endMs: 1150,
              timestampMs: 600,
              confidence: null,
            },
            {
              text: "冬",
              startMs: 1150,
              endMs: 1630,
              timestampMs: 1150,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1630,
              endMs: 2040,
              timestampMs: 1630,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2040,
              endMs: 2580,
              timestampMs: 2040,
              confidence: null,
            },
            {
              text: "已",
              startMs: 2580,
              endMs: 2750,
              timestampMs: 2580,
              confidence: null,
            },
            {
              text: "经",
              startMs: 2750,
              endMs: 2980,
              timestampMs: 2750,
              confidence: null,
            },
            {
              text: "不",
              startMs: 2980,
              endMs: 3250,
              timestampMs: 2980,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3250,
              endMs: 3790,
              timestampMs: 3250,
              confidence: null,
            },
          ]}
          accents={[3, 37, 52, 84, 93, 102, 120]}
        />
      </Sequence>
      <Sequence
        name={"16 / 我的心空出了一块"}
        from={2246}
        durationInFrames={126}
        premountFor={fps}
      >
        <MissingHeart
          duration={126}
          start={74.86666666666666}
          variant={0}
          text={"我的心空出了一块"}
          words={[
            {
              text: "我",
              startMs: 0,
              endMs: 220,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "的",
              startMs: 220,
              endMs: 430,
              timestampMs: 220,
              confidence: null,
            },
            {
              text: "心",
              startMs: 430,
              endMs: 740,
              timestampMs: 430,
              confidence: null,
            },
            {
              text: "空",
              startMs: 740,
              endMs: 990,
              timestampMs: 740,
              confidence: null,
            },
            {
              text: "出",
              startMs: 990,
              endMs: 1270,
              timestampMs: 990,
              confidence: null,
            },
            {
              text: "了",
              startMs: 1270,
              endMs: 1810,
              timestampMs: 1270,
              confidence: null,
            },
            {
              text: "一",
              startMs: 1810,
              endMs: 2340,
              timestampMs: 1810,
              confidence: null,
            },
            {
              text: "块",
              startMs: 2340,
              endMs: 3440,
              timestampMs: 2340,
              confidence: null,
            },
          ]}
          accents={[14, 24, 32, 42, 75]}
        />
      </Sequence>
      <Sequence
        name={"17 / 很高兴遇见你"}
        from={2372}
        durationInFrames={66}
        premountFor={fps}
      >
        <Meet
          duration={66}
          start={79.06666666666666}
          variant={0}
          text={"很高兴遇见你"}
          words={[
            {
              text: "很",
              startMs: 0,
              endMs: 320,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "高",
              startMs: 320,
              endMs: 570,
              timestampMs: 320,
              confidence: null,
            },
            {
              text: "兴",
              startMs: 570,
              endMs: 880,
              timestampMs: 570,
              confidence: null,
            },
            {
              text: "遇",
              startMs: 880,
              endMs: 1130,
              timestampMs: 880,
              confidence: null,
            },
            {
              text: "见",
              startMs: 1130,
              endMs: 1390,
              timestampMs: 1130,
              confidence: null,
            },
            {
              text: "你",
              startMs: 1390,
              endMs: 2000,
              timestampMs: 1390,
              confidence: null,
            },
          ]}
          accents={[14, 36, 45]}
        />
      </Sequence>
      <Sequence
        name={"18 / 让我终究明白"}
        from={2438}
        durationInFrames={68}
        premountFor={fps}
      >
        <Understand
          duration={68}
          start={81.26666666666667}
          variant={0}
          text={"让我终究明白"}
          words={[
            {
              text: "让",
              startMs: 0,
              endMs: 250,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "我",
              startMs: 250,
              endMs: 520,
              timestampMs: 250,
              confidence: null,
            },
            {
              text: "终",
              startMs: 520,
              endMs: 780,
              timestampMs: 520,
              confidence: null,
            },
            {
              text: "究",
              startMs: 780,
              endMs: 1090,
              timestampMs: 780,
              confidence: null,
            },
            {
              text: "明",
              startMs: 1090,
              endMs: 1340,
              timestampMs: 1090,
              confidence: null,
            },
            {
              text: "白",
              startMs: 1340,
              endMs: 2100,
              timestampMs: 1340,
              confidence: null,
            },
          ]}
          accents={[3, 18, 26, 35, 43, 54]}
        />
      </Sequence>
      <Sequence
        name={"19 / 回忆你真是精彩"}
        from={2506}
        durationInFrames={213}
        premountFor={fps}
      >
        <Memory
          duration={213}
          start={83.53333333333333}
          variant={0}
          text={"回忆你真是精彩"}
          words={[
            {
              text: "回",
              startMs: 0,
              endMs: 430,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "忆",
              startMs: 430,
              endMs: 2810,
              timestampMs: 430,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2810,
              endMs: 3090,
              timestampMs: 2810,
              confidence: null,
            },
            {
              text: "真",
              startMs: 3090,
              endMs: 3320,
              timestampMs: 3090,
              confidence: null,
            },
            {
              text: "是",
              startMs: 3320,
              endMs: 4130,
              timestampMs: 3320,
              confidence: null,
            },
            {
              text: "精",
              startMs: 4130,
              endMs: 4480,
              timestampMs: 4130,
              confidence: null,
            },
            {
              text: "彩",
              startMs: 4480,
              endMs: 6170,
              timestampMs: 4480,
              confidence: null,
            },
          ]}
          accents={[6, 94, 127, 136]}
        />
      </Sequence>
      <Sequence
        name={"20 / Interlude"}
        from={2719}
        durationInFrames={193}
        premountFor={fps}
      >
        <Interlude duration={193} start={90.63333333333334} variant={0} />
      </Sequence>
      <Sequence
        name={"21 / 那时我们天天在一起"}
        from={2912}
        durationInFrames={128}
        premountFor={fps}
      >
        <Calendar
          duration={128}
          start={97.06666666666666}
          variant={1}
          text={"那时我们天天在一起"}
          words={[
            {
              text: "那",
              startMs: 0,
              endMs: 210,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "时",
              startMs: 210,
              endMs: 520,
              timestampMs: 210,
              confidence: null,
            },
            {
              text: "我",
              startMs: 520,
              endMs: 840,
              timestampMs: 520,
              confidence: null,
            },
            {
              text: "们",
              startMs: 840,
              endMs: 1320,
              timestampMs: 840,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1320,
              endMs: 1600,
              timestampMs: 1320,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1600,
              endMs: 2120,
              timestampMs: 1600,
              confidence: null,
            },
            {
              text: "在",
              startMs: 2120,
              endMs: 2680,
              timestampMs: 2120,
              confidence: null,
            },
            {
              text: "一",
              startMs: 2680,
              endMs: 3110,
              timestampMs: 2680,
              confidence: null,
            },
            {
              text: "起",
              startMs: 3110,
              endMs: 3800,
              timestampMs: 3110,
              confidence: null,
            },
          ]}
          accents={[8, 18, 41, 50, 69, 82, 95, 114]}
        />
      </Sequence>
      <Sequence
        name={"22 / 太幸福到不需要距离"}
        from={3040}
        durationInFrames={111}
        premountFor={fps}
      >
        <Distance
          duration={111}
          start={101.33333333333333}
          variant={1}
          text={"太幸福到不需要距离"}
          words={[
            {
              text: "太",
              startMs: 0,
              endMs: 240,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "幸",
              startMs: 240,
              endMs: 560,
              timestampMs: 240,
              confidence: null,
            },
            {
              text: "福",
              startMs: 560,
              endMs: 1080,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "到",
              startMs: 1080,
              endMs: 1360,
              timestampMs: 1080,
              confidence: null,
            },
            {
              text: "不",
              startMs: 1360,
              endMs: 1560,
              timestampMs: 1360,
              confidence: null,
            },
            {
              text: "需",
              startMs: 1560,
              endMs: 2240,
              timestampMs: 1560,
              confidence: null,
            },
            {
              text: "要",
              startMs: 2240,
              endMs: 2610,
              timestampMs: 2240,
              confidence: null,
            },
            {
              text: "距",
              startMs: 2610,
              endMs: 3200,
              timestampMs: 2610,
              confidence: null,
            },
            {
              text: "离",
              startMs: 3200,
              endMs: 3710,
              timestampMs: 3200,
              confidence: null,
            },
          ]}
          accents={[9, 19, 44, 51, 69, 83, 97]}
        />
      </Sequence>
      <Sequence
        name={"23 / 很贪心要全世界注意"}
        from={3151}
        durationInFrames={242}
        premountFor={fps}
      >
        <World
          duration={242}
          start={105.03333333333333}
          variant={1}
          text={"很贪心要全世界注意"}
          words={[
            {
              text: "很",
              startMs: 0,
              endMs: 1660,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "贪",
              startMs: 1660,
              endMs: 2110,
              timestampMs: 1660,
              confidence: null,
            },
            {
              text: "心",
              startMs: 2110,
              endMs: 3730,
              timestampMs: 2110,
              confidence: null,
            },
            {
              text: "要",
              startMs: 3730,
              endMs: 4270,
              timestampMs: 3730,
              confidence: null,
            },
            {
              text: "全",
              startMs: 4270,
              endMs: 4770,
              timestampMs: 4270,
              confidence: null,
            },
            {
              text: "世",
              startMs: 4770,
              endMs: 5110,
              timestampMs: 4770,
              confidence: null,
            },
            {
              text: "界",
              startMs: 5110,
              endMs: 5570,
              timestampMs: 5110,
              confidence: null,
            },
            {
              text: "注",
              startMs: 5570,
              endMs: 6500,
              timestampMs: 5570,
              confidence: null,
            },
            {
              text: "意",
              startMs: 6500,
              endMs: 7660,
              timestampMs: 6500,
              confidence: null,
            },
          ]}
          accents={[
            4, 36, 52, 60, 68, 93, 101, 118, 133, 144, 157, 165, 173, 181, 189,
            197, 205, 214, 221, 230, 237,
          ]}
        />
      </Sequence>
      <Sequence
        name={"24 / 只是太年轻"}
        from={3393}
        durationInFrames={63}
        premountFor={fps}
      >
        <Young
          duration={63}
          start={113.1}
          variant={1}
          text={"只是太年轻"}
          words={[
            {
              text: "只",
              startMs: 0,
              endMs: 230,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "是",
              startMs: 230,
              endMs: 560,
              timestampMs: 230,
              confidence: null,
            },
            {
              text: "太",
              startMs: 560,
              endMs: 1050,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "年",
              startMs: 1050,
              endMs: 1540,
              timestampMs: 1050,
              confidence: null,
            },
            {
              text: "轻",
              startMs: 1540,
              endMs: 2120,
              timestampMs: 1540,
              confidence: null,
            },
          ]}
          accents={[3, 11, 20, 52]}
        />
      </Sequence>
      <Sequence
        name={"25 / 快乐和伤心"}
        from={3456}
        durationInFrames={66}
        premountFor={fps}
      >
        <Emotion
          duration={66}
          start={115.2}
          variant={1}
          text={"快乐和伤心"}
          words={[
            {
              text: "快",
              startMs: 0,
              endMs: 320,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "乐",
              startMs: 320,
              endMs: 500,
              timestampMs: 320,
              confidence: null,
            },
            {
              text: "和",
              startMs: 500,
              endMs: 1010,
              timestampMs: 500,
              confidence: null,
            },
            {
              text: "伤",
              startMs: 1010,
              endMs: 1590,
              timestampMs: 1010,
              confidence: null,
            },
            {
              text: "心",
              startMs: 1590,
              endMs: 2000,
              timestampMs: 1590,
              confidence: null,
            },
          ]}
          accents={[5, 12, 20, 36, 52]}
        />
      </Sequence>
      <Sequence
        name={"26 / 都像在演戏"}
        from={3522}
        durationInFrames={69}
        premountFor={fps}
      >
        <Theatre
          duration={69}
          start={117.4}
          variant={1}
          text={"都像在演戏"}
          words={[
            {
              text: "都",
              startMs: 0,
              endMs: 210,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "像",
              startMs: 210,
              endMs: 520,
              timestampMs: 210,
              confidence: null,
            },
            {
              text: "在",
              startMs: 520,
              endMs: 860,
              timestampMs: 520,
              confidence: null,
            },
            {
              text: "演",
              startMs: 860,
              endMs: 1500,
              timestampMs: 860,
              confidence: null,
            },
            {
              text: "戏",
              startMs: 1500,
              endMs: 2290,
              timestampMs: 1500,
              confidence: null,
            },
          ]}
          accents={[3, 11, 19, 51]}
        />
      </Sequence>
      <Sequence
        name={"27 / 一碰就惊天动地"}
        from={3591}
        durationInFrames={90}
        premountFor={fps}
      >
        <Impact
          duration={90}
          start={119.7}
          variant={1}
          text={"一碰就惊天动地"}
          words={[
            {
              text: "一",
              startMs: 0,
              endMs: 160,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "碰",
              startMs: 160,
              endMs: 400,
              timestampMs: 160,
              confidence: null,
            },
            {
              text: "就",
              startMs: 400,
              endMs: 650,
              timestampMs: 400,
              confidence: null,
            },
            {
              text: "惊",
              startMs: 650,
              endMs: 920,
              timestampMs: 650,
              confidence: null,
            },
            {
              text: "天",
              startMs: 920,
              endMs: 1210,
              timestampMs: 920,
              confidence: null,
            },
            {
              text: "动",
              startMs: 1210,
              endMs: 1740,
              timestampMs: 1210,
              confidence: null,
            },
            {
              text: "地",
              startMs: 1740,
              endMs: 2600,
              timestampMs: 1740,
              confidence: null,
            },
          ]}
          accents={[1, 14, 22, 30, 47, 56, 71, 79]}
        />
      </Sequence>
      <Sequence
        name={"28 / 今天看你"}
        from={3681}
        durationInFrames={105}
        premountFor={fps}
      >
        <Today
          duration={105}
          start={122.7}
          variant={1}
          text={"今天看你"}
          words={[
            {
              text: "今",
              startMs: 0,
              endMs: 550,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "天",
              startMs: 550,
              endMs: 2140,
              timestampMs: 550,
              confidence: null,
            },
            {
              text: "看",
              startMs: 2140,
              endMs: 2520,
              timestampMs: 2140,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2520,
              endMs: 2910,
              timestampMs: 2520,
              confidence: null,
            },
          ]}
          accents={[3, 20, 28, 45, 52, 68, 85, 97]}
        />
      </Sequence>
      <Sequence
        name={"29 / 昨天的你去了哪里"}
        from={3786}
        durationInFrames={133}
        premountFor={fps}
      >
        <Yesterday
          duration={133}
          start={126.2}
          variant={1}
          text={"昨天的你去了哪里"}
          words={[
            {
              text: "昨",
              startMs: 0,
              endMs: 280,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "天",
              startMs: 280,
              endMs: 610,
              timestampMs: 280,
              confidence: null,
            },
            {
              text: "的",
              startMs: 610,
              endMs: 820,
              timestampMs: 610,
              confidence: null,
            },
            {
              text: "你",
              startMs: 820,
              endMs: 1100,
              timestampMs: 820,
              confidence: null,
            },
            {
              text: "去",
              startMs: 1100,
              endMs: 1380,
              timestampMs: 1100,
              confidence: null,
            },
            {
              text: "了",
              startMs: 1380,
              endMs: 1800,
              timestampMs: 1380,
              confidence: null,
            },
            {
              text: "哪",
              startMs: 1800,
              endMs: 2390,
              timestampMs: 1800,
              confidence: null,
            },
            {
              text: "里",
              startMs: 2390,
              endMs: 4000,
              timestampMs: 2390,
              confidence: null,
            },
          ]}
          accents={[4, 12, 21, 35, 44, 60, 68, 76, 84, 92, 100, 108, 116, 124]}
        />
      </Sequence>
      <Sequence
        name={"30 / 那年夏天我和你躲在"}
        from={3919}
        durationInFrames={125}
        premountFor={fps}
      >
        <Summer
          duration={125}
          start={130.63333333333333}
          variant={1}
          text={"那年夏天我和你躲在"}
          words={[
            {
              text: "那",
              startMs: 0,
              endMs: 670,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "年",
              startMs: 670,
              endMs: 1100,
              timestampMs: 670,
              confidence: null,
            },
            {
              text: "夏",
              startMs: 1100,
              endMs: 1740,
              timestampMs: 1100,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1740,
              endMs: 2320,
              timestampMs: 1740,
              confidence: null,
            },
            {
              text: "我",
              startMs: 2320,
              endMs: 2520,
              timestampMs: 2320,
              confidence: null,
            },
            {
              text: "和",
              startMs: 2520,
              endMs: 2860,
              timestampMs: 2520,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2860,
              endMs: 3150,
              timestampMs: 2860,
              confidence: null,
            },
            {
              text: "躲",
              startMs: 3150,
              endMs: 3380,
              timestampMs: 3150,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3380,
              endMs: 3940,
              timestampMs: 3380,
              confidence: null,
            },
          ]}
          accents={[7, 40, 55, 64, 72, 88, 96, 104]}
        />
      </Sequence>
      <Sequence
        name={"31 / 这一大片宁静的海"}
        from={4044}
        durationInFrames={135}
        premountFor={fps}
      >
        <QuietSea
          duration={135}
          start={134.8}
          variant={1}
          text={"这一大片宁静的海"}
          words={[
            {
              text: "这",
              startMs: 0,
              endMs: 280,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "一",
              startMs: 280,
              endMs: 550,
              timestampMs: 280,
              confidence: null,
            },
            {
              text: "大",
              startMs: 550,
              endMs: 800,
              timestampMs: 550,
              confidence: null,
            },
            {
              text: "片",
              startMs: 800,
              endMs: 1060,
              timestampMs: 800,
              confidence: null,
            },
            {
              text: "宁",
              startMs: 1060,
              endMs: 1360,
              timestampMs: 1060,
              confidence: null,
            },
            {
              text: "静",
              startMs: 1360,
              endMs: 1890,
              timestampMs: 1360,
              confidence: null,
            },
            {
              text: "的",
              startMs: 1890,
              endMs: 2340,
              timestampMs: 1890,
              confidence: null,
            },
            {
              text: "海",
              startMs: 2340,
              endMs: 3560,
              timestampMs: 2340,
              confidence: null,
            },
          ]}
          accents={[
            3, 11, 19, 27, 35, 43, 60, 68, 75, 84, 91, 107, 115, 123, 132,
          ]}
        />
      </Sequence>
      <Sequence
        name={"32 / 直到后来我们都还在"}
        from={4179}
        durationInFrames={123}
        premountFor={fps}
      >
        <Later
          duration={123}
          start={139.3}
          variant={1}
          text={"直到后来我们都还在"}
          words={[
            {
              text: "直",
              startMs: 0,
              endMs: 610,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "到",
              startMs: 610,
              endMs: 1070,
              timestampMs: 610,
              confidence: null,
            },
            {
              text: "后",
              startMs: 1070,
              endMs: 1630,
              timestampMs: 1070,
              confidence: null,
            },
            {
              text: "来",
              startMs: 1630,
              endMs: 2160,
              timestampMs: 1630,
              confidence: null,
            },
            {
              text: "我",
              startMs: 2160,
              endMs: 2490,
              timestampMs: 2160,
              confidence: null,
            },
            {
              text: "们",
              startMs: 2490,
              endMs: 2730,
              timestampMs: 2490,
              confidence: null,
            },
            {
              text: "都",
              startMs: 2730,
              endMs: 2980,
              timestampMs: 2730,
              confidence: null,
            },
            {
              text: "还",
              startMs: 2980,
              endMs: 3540,
              timestampMs: 2980,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3540,
              endMs: 3950,
              timestampMs: 3540,
              confidence: null,
            },
          ]}
          accents={[4, 22, 37, 54, 69, 77, 84, 101, 110]}
        />
      </Sequence>
      <Sequence
        name={"33 / 对这个世界充满期待"}
        from={4302}
        durationInFrames={134}
        premountFor={fps}
      >
        <Expect
          duration={134}
          start={143.4}
          variant={1}
          text={"对这个世界充满期待"}
          words={[
            {
              text: "对",
              startMs: 0,
              endMs: 250,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "这",
              startMs: 250,
              endMs: 590,
              timestampMs: 250,
              confidence: null,
            },
            {
              text: "个",
              startMs: 590,
              endMs: 700,
              timestampMs: 590,
              confidence: null,
            },
            {
              text: "世",
              startMs: 700,
              endMs: 1080,
              timestampMs: 700,
              confidence: null,
            },
            {
              text: "界",
              startMs: 1080,
              endMs: 1310,
              timestampMs: 1080,
              confidence: null,
            },
            {
              text: "充",
              startMs: 1310,
              endMs: 1840,
              timestampMs: 1310,
              confidence: null,
            },
            {
              text: "满",
              startMs: 1840,
              endMs: 2330,
              timestampMs: 1840,
              confidence: null,
            },
            {
              text: "期",
              startMs: 2330,
              endMs: 3510,
              timestampMs: 2330,
              confidence: null,
            },
            {
              text: "待",
              startMs: 3510,
              endMs: 4190,
              timestampMs: 3510,
              confidence: null,
            },
          ]}
          accents={[3, 11, 22, 35, 43, 59, 72, 83, 91, 99, 107, 115, 123, 131]}
        />
      </Sequence>
      <Sequence
        name={"34 / 今年冬天你已经不在"}
        from={4436}
        durationInFrames={123}
        premountFor={fps}
      >
        <Winter
          duration={123}
          start={147.86666666666667}
          variant={1}
          text={"今年冬天你已经不在"}
          words={[
            {
              text: "今",
              startMs: 0,
              endMs: 620,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "年",
              startMs: 620,
              endMs: 1170,
              timestampMs: 620,
              confidence: null,
            },
            {
              text: "冬",
              startMs: 1170,
              endMs: 1640,
              timestampMs: 1170,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1640,
              endMs: 2050,
              timestampMs: 1640,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2050,
              endMs: 2540,
              timestampMs: 2050,
              confidence: null,
            },
            {
              text: "已",
              startMs: 2540,
              endMs: 2780,
              timestampMs: 2540,
              confidence: null,
            },
            {
              text: "经",
              startMs: 2780,
              endMs: 3040,
              timestampMs: 2780,
              confidence: null,
            },
            {
              text: "不",
              startMs: 3040,
              endMs: 3280,
              timestampMs: 3040,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3280,
              endMs: 3810,
              timestampMs: 3280,
              confidence: null,
            },
          ]}
          accents={[5, 21, 37, 52, 61, 69, 78, 85, 93, 101, 118]}
        />
      </Sequence>
      <Sequence
        name={"35 / 我的心空出了一块"}
        from={4559}
        durationInFrames={127}
        premountFor={fps}
      >
        <MissingHeart
          duration={127}
          start={151.96666666666667}
          variant={1}
          text={"我的心空出了一块"}
          words={[
            {
              text: "我",
              startMs: 0,
              endMs: 240,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "的",
              startMs: 240,
              endMs: 450,
              timestampMs: 240,
              confidence: null,
            },
            {
              text: "心",
              startMs: 450,
              endMs: 800,
              timestampMs: 450,
              confidence: null,
            },
            {
              text: "空",
              startMs: 800,
              endMs: 1050,
              timestampMs: 800,
              confidence: null,
            },
            {
              text: "出",
              startMs: 1050,
              endMs: 1320,
              timestampMs: 1050,
              confidence: null,
            },
            {
              text: "了",
              startMs: 1320,
              endMs: 1870,
              timestampMs: 1320,
              confidence: null,
            },
            {
              text: "一",
              startMs: 1870,
              endMs: 2370,
              timestampMs: 1870,
              confidence: null,
            },
            {
              text: "块",
              startMs: 2370,
              endMs: 3710,
              timestampMs: 2370,
              confidence: null,
            },
          ]}
          accents={[2, 10, 33, 42, 58, 74, 91, 99, 107, 122]}
        />
      </Sequence>
      <Sequence
        name={"36 / 很高兴遇见你"}
        from={4686}
        durationInFrames={65}
        premountFor={fps}
      >
        <Meet
          duration={65}
          start={156.2}
          variant={1}
          text={"很高兴遇见你"}
          words={[
            {
              text: "很",
              startMs: 0,
              endMs: 240,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "高",
              startMs: 240,
              endMs: 540,
              timestampMs: 240,
              confidence: null,
            },
            {
              text: "兴",
              startMs: 540,
              endMs: 860,
              timestampMs: 540,
              confidence: null,
            },
            {
              text: "遇",
              startMs: 860,
              endMs: 1110,
              timestampMs: 860,
              confidence: null,
            },
            {
              text: "见",
              startMs: 1110,
              endMs: 1370,
              timestampMs: 1110,
              confidence: null,
            },
            {
              text: "你",
              startMs: 1370,
              endMs: 1920,
              timestampMs: 1370,
              confidence: null,
            },
          ]}
          accents={[4, 12, 21, 35, 44, 56]}
        />
      </Sequence>
      <Sequence
        name={"37 / 让我终究明白"}
        from={4751}
        durationInFrames={70}
        premountFor={fps}
      >
        <Understand
          duration={70}
          start={158.36666666666667}
          variant={1}
          text={"让我终究明白"}
          words={[
            {
              text: "让",
              startMs: 0,
              endMs: 260,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "我",
              startMs: 260,
              endMs: 540,
              timestampMs: 260,
              confidence: null,
            },
            {
              text: "终",
              startMs: 540,
              endMs: 800,
              timestampMs: 540,
              confidence: null,
            },
            {
              text: "究",
              startMs: 800,
              endMs: 1110,
              timestampMs: 800,
              confidence: null,
            },
            {
              text: "明",
              startMs: 1110,
              endMs: 1320,
              timestampMs: 1110,
              confidence: null,
            },
            {
              text: "白",
              startMs: 1320,
              endMs: 2140,
              timestampMs: 1320,
              confidence: null,
            },
          ]}
          accents={[4, 11, 19, 27, 35, 43, 51, 59, 67]}
        />
      </Sequence>
      <Sequence
        name={"38 / 回忆你真是精彩"}
        from={4821}
        durationInFrames={273}
        premountFor={fps}
      >
        <Memory
          duration={273}
          start={160.7}
          variant={1}
          text={"回忆你真是精彩"}
          words={[
            {
              text: "回",
              startMs: 0,
              endMs: 430,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "忆",
              startMs: 430,
              endMs: 2780,
              timestampMs: 430,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2780,
              endMs: 3080,
              timestampMs: 2780,
              confidence: null,
            },
            {
              text: "真",
              startMs: 3080,
              endMs: 3300,
              timestampMs: 3080,
              confidence: null,
            },
            {
              text: "是",
              startMs: 3300,
              endMs: 4070,
              timestampMs: 3300,
              confidence: null,
            },
            {
              text: "精",
              startMs: 4070,
              endMs: 4410,
              timestampMs: 4070,
              confidence: null,
            },
            {
              text: "彩",
              startMs: 4410,
              endMs: 7280,
              timestampMs: 4410,
              confidence: null,
            },
          ]}
          accents={[
            5, 30, 38, 53, 62, 70, 78, 86, 94, 102, 110, 118, 126, 134, 144,
            158, 166, 182, 190, 198, 207, 214, 222, 230, 238, 247, 254, 262,
          ]}
        />
      </Sequence>
      <Sequence
        name={"39 / 还记得一起努力"}
        from={5094}
        durationInFrames={104}
        premountFor={fps}
      >
        <Effort
          duration={104}
          start={169.8}
          variant={2}
          text={"还记得一起努力"}
          words={[
            {
              text: "还",
              startMs: 0,
              endMs: 580,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "记",
              startMs: 580,
              endMs: 1170,
              timestampMs: 580,
              confidence: null,
            },
            {
              text: "得",
              startMs: 1170,
              endMs: 1660,
              timestampMs: 1170,
              confidence: null,
            },
            {
              text: "一",
              startMs: 1660,
              endMs: 2180,
              timestampMs: 1660,
              confidence: null,
            },
            {
              text: "起",
              startMs: 2180,
              endMs: 2530,
              timestampMs: 2180,
              confidence: null,
            },
            {
              text: "努",
              startMs: 2530,
              endMs: 3020,
              timestampMs: 2530,
              confidence: null,
            },
            {
              text: "力",
              startMs: 3020,
              endMs: 3450,
              timestampMs: 3020,
              confidence: null,
            },
          ]}
          accents={[4, 14, 22, 38, 46, 54, 67, 78, 86, 94]}
        />
      </Sequence>
      <Sequence
        name={"40 / 还有那些一言为定"}
        from={5198}
        durationInFrames={152}
        premountFor={fps}
      >
        <Promise
          duration={152}
          start={173.26666666666668}
          variant={2}
          text={"还有那些一言为定"}
          words={[
            {
              text: "还",
              startMs: 0,
              endMs: 360,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "有",
              startMs: 360,
              endMs: 900,
              timestampMs: 360,
              confidence: null,
            },
            {
              text: "那",
              startMs: 900,
              endMs: 1140,
              timestampMs: 900,
              confidence: null,
            },
            {
              text: "些",
              startMs: 1140,
              endMs: 2270,
              timestampMs: 1140,
              confidence: null,
            },
            {
              text: "一",
              startMs: 2270,
              endMs: 2610,
              timestampMs: 2270,
              confidence: null,
            },
            {
              text: "言",
              startMs: 2610,
              endMs: 2840,
              timestampMs: 2610,
              confidence: null,
            },
            {
              text: "为",
              startMs: 2840,
              endMs: 3350,
              timestampMs: 2840,
              confidence: null,
            },
            {
              text: "定",
              startMs: 3350,
              endMs: 5050,
              timestampMs: 3350,
              confidence: null,
            },
          ]}
          accents={[5, 14, 35, 47, 58, 71, 79, 103, 110, 119, 127, 135, 143]}
        />
      </Sequence>
      <Sequence
        name={"41 / 现在我就当过去是种学习"}
        from={5350}
        durationInFrames={169}
        premountFor={fps}
      >
        <Learning
          duration={169}
          start={178.33333333333334}
          variant={2}
          text={"现在我就当过去是种学习"}
          words={[
            {
              text: "现",
              startMs: 0,
              endMs: 630,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "在",
              startMs: 630,
              endMs: 1240,
              timestampMs: 630,
              confidence: null,
            },
            {
              text: "我",
              startMs: 1240,
              endMs: 1560,
              timestampMs: 1240,
              confidence: null,
            },
            {
              text: "就",
              startMs: 1560,
              endMs: 2180,
              timestampMs: 1560,
              confidence: null,
            },
            {
              text: "当",
              startMs: 2180,
              endMs: 2630,
              timestampMs: 2180,
              confidence: null,
            },
            {
              text: "过",
              startMs: 2630,
              endMs: 2980,
              timestampMs: 2630,
              confidence: null,
            },
            {
              text: "去",
              startMs: 2980,
              endMs: 3530,
              timestampMs: 2980,
              confidence: null,
            },
            {
              text: "是",
              startMs: 3530,
              endMs: 3880,
              timestampMs: 3530,
              confidence: null,
            },
            {
              text: "种",
              startMs: 3880,
              endMs: 4330,
              timestampMs: 3880,
              confidence: null,
            },
            {
              text: "学",
              startMs: 4330,
              endMs: 4730,
              timestampMs: 4330,
              confidence: null,
            },
            {
              text: "习",
              startMs: 4730,
              endMs: 5440,
              timestampMs: 4730,
              confidence: null,
            },
          ]}
          accents={[
            4, 11, 23, 42, 51, 60, 71, 87, 95, 103, 111, 119, 128, 135, 144,
            151, 159, 167,
          ]}
        />
      </Sequence>
      <Sequence
        name={"42 / 虽然好不容易"}
        from={5519}
        durationInFrames={204}
        premountFor={fps}
      >
        <Difficult
          duration={204}
          start={183.96666666666667}
          variant={2}
          text={"虽然好不容易"}
          words={[
            {
              text: "虽",
              startMs: 0,
              endMs: 450,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "然",
              startMs: 450,
              endMs: 830,
              timestampMs: 450,
              confidence: null,
            },
            {
              text: "好",
              startMs: 830,
              endMs: 1830,
              timestampMs: 830,
              confidence: null,
            },
            {
              text: "不",
              startMs: 1830,
              endMs: 1920,
              timestampMs: 1830,
              confidence: null,
            },
            {
              text: "容",
              startMs: 1920,
              endMs: 2570,
              timestampMs: 1920,
              confidence: null,
            },
            {
              text: "易",
              startMs: 2570,
              endMs: 3030,
              timestampMs: 2570,
              confidence: null,
            },
          ]}
          accents={[
            6, 15, 29, 39, 47, 55, 63, 79, 86, 95, 103, 111, 119, 127, 135, 143,
          ]}
        />
      </Sequence>
      <Sequence
        name={"43 / 那年夏天我和你躲在"}
        from={5723}
        durationInFrames={121}
        premountFor={fps}
      >
        <Summer
          duration={121}
          start={190.76666666666668}
          variant={2}
          text={"那年夏天我和你躲在"}
          words={[
            {
              text: "那",
              startMs: 0,
              endMs: 560,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "年",
              startMs: 560,
              endMs: 1010,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "夏",
              startMs: 1010,
              endMs: 1620,
              timestampMs: 1010,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1620,
              endMs: 2130,
              timestampMs: 1620,
              confidence: null,
            },
            {
              text: "我",
              startMs: 2130,
              endMs: 2430,
              timestampMs: 2130,
              confidence: null,
            },
            {
              text: "和",
              startMs: 2430,
              endMs: 2700,
              timestampMs: 2430,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2700,
              endMs: 3010,
              timestampMs: 2700,
              confidence: null,
            },
            {
              text: "躲",
              startMs: 3010,
              endMs: 3250,
              timestampMs: 3010,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3250,
              endMs: 3670,
              timestampMs: 3250,
              confidence: null,
            },
          ]}
          accents={[52, 92]}
        />
      </Sequence>
      <Sequence
        name={"44 / 这一大片宁静的海"}
        from={5844}
        durationInFrames={136}
        premountFor={fps}
      >
        <QuietSea
          duration={136}
          start={194.8}
          variant={2}
          text={"这一大片宁静的海"}
          words={[
            {
              text: "这",
              startMs: 0,
              endMs: 290,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "一",
              startMs: 290,
              endMs: 560,
              timestampMs: 290,
              confidence: null,
            },
            {
              text: "大",
              startMs: 560,
              endMs: 790,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "片",
              startMs: 790,
              endMs: 1070,
              timestampMs: 790,
              confidence: null,
            },
            {
              text: "宁",
              startMs: 1070,
              endMs: 1360,
              timestampMs: 1070,
              confidence: null,
            },
            {
              text: "静",
              startMs: 1360,
              endMs: 1910,
              timestampMs: 1360,
              confidence: null,
            },
            {
              text: "的",
              startMs: 1910,
              endMs: 2320,
              timestampMs: 1910,
              confidence: null,
            },
            {
              text: "海",
              startMs: 2320,
              endMs: 3040,
              timestampMs: 2320,
              confidence: null,
            },
          ]}
          accents={[43]}
        />
      </Sequence>
      <Sequence
        name={"45 / 直到后来我们都还在"}
        from={5980}
        durationInFrames={123}
        premountFor={fps}
      >
        <Later
          duration={123}
          start={199.33333333333334}
          variant={2}
          text={"直到后来我们都还在"}
          words={[
            {
              text: "直",
              startMs: 0,
              endMs: 560,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "到",
              startMs: 560,
              endMs: 1010,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "后",
              startMs: 1010,
              endMs: 1640,
              timestampMs: 1010,
              confidence: null,
            },
            {
              text: "来",
              startMs: 1640,
              endMs: 2170,
              timestampMs: 1640,
              confidence: null,
            },
            {
              text: "我",
              startMs: 2170,
              endMs: 2460,
              timestampMs: 2170,
              confidence: null,
            },
            {
              text: "们",
              startMs: 2460,
              endMs: 2720,
              timestampMs: 2460,
              confidence: null,
            },
            {
              text: "都",
              startMs: 2720,
              endMs: 2960,
              timestampMs: 2720,
              confidence: null,
            },
            {
              text: "还",
              startMs: 2960,
              endMs: 3520,
              timestampMs: 2960,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3520,
              endMs: 3900,
              timestampMs: 3520,
              confidence: null,
            },
          ]}
          accents={[20, 37, 69, 84, 94, 109, 119]}
        />
      </Sequence>
      <Sequence
        name={"46 / 对这个世界充满期待"}
        from={6103}
        durationInFrames={133}
        premountFor={fps}
      >
        <Expect
          duration={133}
          start={203.43333333333334}
          variant={2}
          text={"对这个世界充满期待"}
          words={[
            {
              text: "对",
              startMs: 0,
              endMs: 230,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "这",
              startMs: 230,
              endMs: 550,
              timestampMs: 230,
              confidence: null,
            },
            {
              text: "个",
              startMs: 550,
              endMs: 680,
              timestampMs: 550,
              confidence: null,
            },
            {
              text: "世",
              startMs: 680,
              endMs: 1060,
              timestampMs: 680,
              confidence: null,
            },
            {
              text: "界",
              startMs: 1060,
              endMs: 1280,
              timestampMs: 1060,
              confidence: null,
            },
            {
              text: "充",
              startMs: 1280,
              endMs: 1740,
              timestampMs: 1280,
              confidence: null,
            },
            {
              text: "满",
              startMs: 1740,
              endMs: 2290,
              timestampMs: 1740,
              confidence: null,
            },
            {
              text: "期",
              startMs: 2290,
              endMs: 3480,
              timestampMs: 2290,
              confidence: null,
            },
            {
              text: "待",
              startMs: 3480,
              endMs: 4170,
              timestampMs: 3480,
              confidence: null,
            },
          ]}
          accents={[10, 22, 40, 59, 66, 74, 98, 106, 114, 122, 130]}
        />
      </Sequence>
      <Sequence
        name={"47 / 今年冬天你已经不在"}
        from={6236}
        durationInFrames={122}
        premountFor={fps}
      >
        <Winter
          duration={122}
          start={207.86666666666667}
          variant={2}
          text={"今年冬天你已经不在"}
          words={[
            {
              text: "今",
              startMs: 0,
              endMs: 560,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "年",
              startMs: 560,
              endMs: 1120,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "冬",
              startMs: 1120,
              endMs: 1640,
              timestampMs: 1120,
              confidence: null,
            },
            {
              text: "天",
              startMs: 1640,
              endMs: 2030,
              timestampMs: 1640,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2030,
              endMs: 2460,
              timestampMs: 2030,
              confidence: null,
            },
            {
              text: "已",
              startMs: 2460,
              endMs: 2770,
              timestampMs: 2460,
              confidence: null,
            },
            {
              text: "经",
              startMs: 2770,
              endMs: 3020,
              timestampMs: 2770,
              confidence: null,
            },
            {
              text: "不",
              startMs: 3020,
              endMs: 3230,
              timestampMs: 3020,
              confidence: null,
            },
            {
              text: "在",
              startMs: 3230,
              endMs: 3810,
              timestampMs: 3230,
              confidence: null,
            },
          ]}
          accents={[4, 12, 20, 29, 36, 52, 61, 69, 77, 85, 93, 101, 120]}
        />
      </Sequence>
      <Sequence
        name={"48 / 我的心空出了一块"}
        from={6358}
        durationInFrames={129}
        premountFor={fps}
      >
        <MissingHeart
          duration={129}
          start={211.93333333333334}
          variant={2}
          text={"我的心空出了一块"}
          words={[
            {
              text: "我",
              startMs: 0,
              endMs: 250,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "的",
              startMs: 250,
              endMs: 470,
              timestampMs: 250,
              confidence: null,
            },
            {
              text: "心",
              startMs: 470,
              endMs: 810,
              timestampMs: 470,
              confidence: null,
            },
            {
              text: "空",
              startMs: 810,
              endMs: 1060,
              timestampMs: 810,
              confidence: null,
            },
            {
              text: "出",
              startMs: 1060,
              endMs: 1350,
              timestampMs: 1060,
              confidence: null,
            },
            {
              text: "了",
              startMs: 1350,
              endMs: 1850,
              timestampMs: 1350,
              confidence: null,
            },
            {
              text: "一",
              startMs: 1850,
              endMs: 2410,
              timestampMs: 1850,
              confidence: null,
            },
            {
              text: "块",
              startMs: 2410,
              endMs: 2810,
              timestampMs: 2410,
              confidence: null,
            },
          ]}
          accents={[11, 19, 26, 33, 43, 59, 67, 75, 91, 99, 107, 115, 123]}
        />
      </Sequence>
      <Sequence
        name={"49 / 很高兴遇见你"}
        from={6487}
        durationInFrames={63}
        premountFor={fps}
      >
        <Meet
          duration={63}
          start={216.23333333333332}
          variant={2}
          text={"很高兴遇见你"}
          words={[
            {
              text: "很",
              startMs: 0,
              endMs: 250,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "高",
              startMs: 250,
              endMs: 510,
              timestampMs: 250,
              confidence: null,
            },
            {
              text: "兴",
              startMs: 510,
              endMs: 830,
              timestampMs: 510,
              confidence: null,
            },
            {
              text: "遇",
              startMs: 830,
              endMs: 1080,
              timestampMs: 830,
              confidence: null,
            },
            {
              text: "见",
              startMs: 1080,
              endMs: 1360,
              timestampMs: 1080,
              confidence: null,
            },
            {
              text: "你",
              startMs: 1360,
              endMs: 1860,
              timestampMs: 1360,
              confidence: null,
            },
          ]}
          accents={[2, 11, 19, 34, 43, 59]}
        />
      </Sequence>
      <Sequence
        name={"50 / 让我终究明白"}
        from={6550}
        durationInFrames={72}
        premountFor={fps}
      >
        <Understand
          duration={72}
          start={218.33333333333334}
          variant={2}
          text={"让我终究明白"}
          words={[
            {
              text: "让",
              startMs: 0,
              endMs: 280,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "我",
              startMs: 280,
              endMs: 560,
              timestampMs: 280,
              confidence: null,
            },
            {
              text: "终",
              startMs: 560,
              endMs: 820,
              timestampMs: 560,
              confidence: null,
            },
            {
              text: "究",
              startMs: 820,
              endMs: 1130,
              timestampMs: 820,
              confidence: null,
            },
            {
              text: "明",
              startMs: 1130,
              endMs: 1350,
              timestampMs: 1130,
              confidence: null,
            },
            {
              text: "白",
              startMs: 1350,
              endMs: 2190,
              timestampMs: 1350,
              confidence: null,
            },
          ]}
          accents={[4, 11, 19, 28, 36, 45, 52, 60, 69]}
        />
      </Sequence>
      <Sequence
        name={"51 / 回忆你真是精彩"}
        from={6622}
        durationInFrames={535}
        premountFor={fps}
      >
        <Memory
          duration={535}
          start={220.73333333333332}
          variant={2}
          text={"回忆你真是精彩"}
          words={[
            {
              text: "回",
              startMs: 0,
              endMs: 430,
              timestampMs: 0,
              confidence: null,
            },
            {
              text: "忆",
              startMs: 430,
              endMs: 2740,
              timestampMs: 430,
              confidence: null,
            },
            {
              text: "你",
              startMs: 2740,
              endMs: 3020,
              timestampMs: 2740,
              confidence: null,
            },
            {
              text: "真",
              startMs: 3020,
              endMs: 3260,
              timestampMs: 3020,
              confidence: null,
            },
            {
              text: "是",
              startMs: 3260,
              endMs: 15050,
              timestampMs: 3260,
              confidence: null,
            },
            {
              text: "精",
              startMs: 15050,
              endMs: 15580,
              timestampMs: 15050,
              confidence: null,
            },
            {
              text: "彩",
              startMs: 15580,
              endMs: 17820,
              timestampMs: 15580,
              confidence: null,
            },
          ]}
          accents={[
            4, 12, 28, 37, 53, 61, 69, 77, 85, 93, 101, 109, 117, 124, 133, 149,
            157, 165, 173, 181, 189, 197, 214, 222, 230, 238, 246, 254, 261,
            278, 286, 294, 302, 309, 318, 327, 366,
          ]}
        />
      </Sequence>
      <Sequence
        name={"52 / Ending"}
        from={7157}
        durationInFrames={386}
        premountFor={fps}
      >
        <Ending duration={386} start={238.56666666666666} variant={0} />
      </Sequence>
      <Progress />
    </AbsoluteFill>
  );
};
