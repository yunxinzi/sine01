import {
  AbsoluteFill,
  Sequence,
  useCurrentFrame,
  useVideoConfig,
  staticFile,
} from "remotion";
import { Audio } from "@remotion/media";
import { Theatre, Impact } from "./registry";
import { C, MONO } from "./design";
// The production timeline is generated only after genuine source timestamps have been imported.
export const DesignSample = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <Sequence
        name="都像在演戏 / design study"
        durationInFrames={3.5 * fps}
        premountFor={fps}
      >
        <Theatre duration={3.5 * fps} />
      </Sequence>
      <Sequence
        name="一碰就惊天动地 / design study"
        from={3.5 * fps}
        durationInFrames={3.5 * fps}
        premountFor={fps}
      >
        <Impact duration={3.5 * fps} />
      </Sequence>
    </AbsoluteFill>
  );
};
export const Progress = () => {
  const f = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return (
    <div
      style={{
        position: "absolute",
        left: 56,
        right: 56,
        bottom: 49,
        height: 3,
        background: C.orange,
        width: (1808 * f) / (durationInFrames - 1),
      }}
    />
  );
};
export const Soundtrack = () => {
  const { fps } = useVideoConfig();
  return (
    <Audio
      name="Original soundtrack"
      src={staticFile("music.mp3")}
      premountFor={fps}
    />
  );
};
export const ProofLabel = () => (
  <div
    style={{
      position: "absolute",
      right: 80,
      top: 73,
      fontFamily: MONO,
      fontSize: 18,
      color: C.orange,
    }}
  >
    DESIGN STUDY / AUDIO ALIGNMENT PENDING
  </div>
);
