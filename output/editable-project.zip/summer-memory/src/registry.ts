import { Effort, Promise, Learning, Difficult } from "./scenes/19-Bridge";
import { Calendar } from "./scenes/01-Calendar";
import { Distance } from "./scenes/02-Distance";
import { World } from "./scenes/03-World";
import { Young } from "./scenes/04-Young";
import { Emotion } from "./scenes/05-Emotion";
import { Theatre } from "./scenes/06-Theatre";
import { Impact } from "./scenes/07-Impact";
import { Today } from "./scenes/08-Today";
import { Yesterday } from "./scenes/09-Yesterday";
import { Summer } from "./scenes/10-Summer";
import { QuietSea } from "./scenes/11-Sea";
import { Later } from "./scenes/12-Later";
import { Expect } from "./scenes/13-Expect";
import { Winter } from "./scenes/14-Winter";
import { MissingHeart } from "./scenes/15-Heart";
import { Meet } from "./scenes/16-Meet";
import { Understand } from "./scenes/17-Understand";
import { Memory } from "./scenes/18-Memory";
import { Opening, Interlude, Ending } from "./scenes/00-Instrumental";
export {
  Effort,
  Promise,
  Learning,
  Difficult,
  Calendar,
  Distance,
  World,
  Young,
  Emotion,
  Theatre,
  Impact,
  Today,
  Yesterday,
  Summer,
  QuietSea,
  Later,
  Expect,
  Winter,
  MissingHeart,
  Meet,
  Understand,
  Memory,
  Opening,
  Interlude,
  Ending,
};
export const sceneRegistry = {
  Effort,
  Promise,
  Learning,
  Difficult,
  Calendar,
  Distance,
  World,
  Young,
  Emotion,
  Theatre,
  Impact,
  Today,
  Yesterday,
  Summer,
  QuietSea,
  Later,
  Expect,
  Winter,
  MissingHeart,
  Meet,
  Understand,
  Memory,
  Opening,
  Interlude,
  Ending,
};
export type SceneName = keyof typeof sceneRegistry;
