from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parent.parent
files=[root/n for n in ['package.json','package-lock.json','tsconfig.json','remotion.config.ts','requirements-helpers.txt','eslint.config.mjs','.gitignore']]
for name in ['src','public','scripts']:
 files += [p for p in (root/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [root/'lyrics-timing.json']
files += list((root/'rework').glob('*.md'))
files += [root/'rework/analysis/frame-scan-summary.json']
files += list((root/'rework/review/v3-seconds').glob('*'))+list((root/'rework/review/v3-transitions').glob('*'))
files += [root/'rework/review/v3-seconds.jpg',root/'rework/review/v3-transitions.jpg']
files += list((root/'output/rework').glob('*.json'))
with ZipFile(root/'output/rework/rework-project.zip','w',ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('mg-rework/README.md',(root/'rework/README.md').read_text())
 for p in files:z.write(p,'mg-rework/'+str(p.relative_to(root)))
with ZipFile(root/'output/rework/rework-project.zip') as z:assert z.testzip() is None
print('Rework project archive:',(root/'output/rework/rework-project.zip').stat().st_size,'bytes')
