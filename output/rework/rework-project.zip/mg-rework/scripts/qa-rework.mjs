import { bundle } from "@remotion/bundler";
import { openBrowser, selectComposition } from "@remotion/renderer";
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
const require = createRequire(import.meta.url);
const dist = path.dirname(require.resolve("@remotion/renderer"));
const { prepareServer } = require(path.join(dist, "prepare-server.js"));
const { setPropsAndEnv } = require(path.join(dist, "set-props-and-env.js"));
const { seekToFrame } = require(path.join(dist, "seek-to-frame.js"));
const timeline = JSON.parse(fs.readFileSync("lyrics-timing.json", "utf8"));
const bundlePath = await bundle({ entryPoint: path.resolve("src/index.ts") });
const server = await prepareServer({
  webpackConfigOrServeUrl: bundlePath,
  port: null,
  remotionRoot: process.cwd(),
  offthreadVideoThreads: 1,
  logLevel: "error",
  indent: false,
  offthreadVideoCacheSizeInBytes: null,
  binariesDirectory: null,
  forceIPv4: true,
  sampleRate: 48000,
});
const browser = await openBrowser("chrome", {
  browserExecutable: process.env.CHROME_PATH ?? "/usr/bin/chromium",
  logLevel: "error",
});
const errors = [];
const warnings = [];
const samples = [];
try {
  const comp = await selectComposition({
    serveUrl: server.serveUrl,
    id: "Rework8Sec",
    puppeteerInstance: browser,
  });
  const page = await browser.newPage({
    context: server.sourceMap,
    logLevel: "error",
    indent: false,
    pageIndex: 0,
    onBrowserLog: (l) => {
      if (l.type === "error") errors.push(l.text);
    },
    onLog: () => {},
  });
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
  await setPropsAndEnv({
    page,
    serveUrl: server.serveUrl,
    serializedInputPropsWithCustomSchema: "{}",
    envVariables: {},
    initialFrame: 0,
    timeoutInMilliseconds: 30000,
    proxyPort: server.offthreadPort,
    retriesRemaining: 0,
    audioEnabled: false,
    videoEnabled: true,
    indent: false,
    logLevel: "error",
    onServeUrlVisited: () => {},
    isMainTab: true,
    mediaCacheSizeInBytes: 512 * 1024 * 1024,
    initialMemoryAvailable: 8 * 1024 ** 3,
    darkMode: false,
    sampleRate: 48000,
  });
  await page.evaluate(
    (c) =>
      window.remotion_setBundleMode({
        type: "composition",
        compositionName: c.id,
        serializedResolvedPropsWithSchema: JSON.stringify(c.props),
        compositionDurationInFrames: c.durationInFrames,
        compositionFps: c.fps,
        compositionHeight: c.height,
        compositionWidth: c.width,
        compositionDefaultCodec: null,
        compositionDefaultOutName: null,
        compositionDefaultVideoImageFormat: null,
        compositionDefaultPixelFormat: null,
        compositionDefaultProResProfile: null,
        compositionDefaultSampleRate: null,
      }),
    comp,
  );
  const frames = new Set(Array.from({ length: 240 }, (_, i) => i));
  for (const frame of [...frames].sort((a, b) => a - b)) {
    await seekToFrame({
      frame,
      page,
      composition: "Rework8Sec",
      timeoutInMilliseconds: 30000,
      logLevel: "error",
      indent: false,
      attempt: 1,
    });
    const result = await page.evaluate(() => {
      const cv = document.createElement("canvas");
      const ctx = cv.getContext("2d");
      const nodes = [
        ...document.querySelectorAll(
          'text[data-hero]:not([aria-hidden="true"])',
        ),
      ].filter((n) => {
        for (let p = n; p; p = p.parentElement) {
          const cs = getComputedStyle(p);
          if (
            cs.display === "none" ||
            cs.visibility === "hidden" ||
            Number(cs.opacity) === 0
          )
            return false;
        }
        return true;
      });
      const boxes = nodes.map((n) => {
        const cs = getComputedStyle(n);
        ctx.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
        const m = ctx.measureText(n.textContent);
        const x = Number(n.getAttribute("x") ?? 0),
          y = Number(n.getAttribute("y") ?? 0),
          matrix = n.getScreenCTM();
        const corners = [
          [x - m.actualBoundingBoxLeft, y - m.actualBoundingBoxAscent],
          [x + m.actualBoundingBoxRight, y - m.actualBoundingBoxAscent],
          [x - m.actualBoundingBoxLeft, y + m.actualBoundingBoxDescent],
          [x + m.actualBoundingBoxRight, y + m.actualBoundingBoxDescent],
        ].map(([a, b]) => new DOMPoint(a, b).matrixTransform(matrix));
        const xs = corners.map((p) => p.x),
          ys = corners.map((p) => p.y);
        return {
          text: n.textContent,
          x: Math.min(...xs),
          y: Math.min(...ys),
          right: Math.max(...xs),
          bottom: Math.max(...ys),
        };
      });
      const out = boxes.filter(
        (r) => r.x < 0 || r.y < 0 || r.right > 1920 || r.bottom > 1080,
      );
      return {
        boxes,
        out,
        replacementGlyph: boxes.some((b) => b.text.includes("\uFFFD")),
        fontReady: document.fonts.check("900 100px SummerBlack"),
      };
    });
    samples.push({ frame, ...result });
    if (result.out.length)
      warnings.push({ frame, kind: "bounds", items: result.out });
    if (result.overlaps?.length)
      warnings.push({ frame, kind: "text-overlap", items: result.overlaps });
    if (result.replacementGlyph || !result.fontReady)
      errors.push({ frame, result });
  }
  const report = {
    checkedFrames: samples.length,
    scope:
      "Actual painted glyph bounds computed using Canvas text metrics and SVG matrices for all 240 frames. Intentional entrance crops are separated from sustained settled cropping.",
    errors,
    warnings,
    samples,
  };
  fs.writeFileSync(
    "output/rework/painted-bounds-qa.json",
    JSON.stringify(report, null, 2),
  );
  console.log(
    "Layout QA",
    samples.length,
    "frames;",
    errors.length,
    "errors;",
    warnings.length,
    "review warnings",
  );
  console.log(JSON.stringify(warnings.slice(0, 18), null, 2));
  if (errors.length) process.exitCode = 1;
} finally {
  await browser.close({ silent: true });
  await server.closeServer(true);
}
