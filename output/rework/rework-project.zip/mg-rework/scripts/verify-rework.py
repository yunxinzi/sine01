import subprocess,json,numpy as np
from pathlib import Path
from scipy.signal import correlate,correlation_lags
from fontTools.ttLib import TTFont
root=Path(__file__).resolve().parent.parent;p=root/'output/rework/sample-v3.mp4'
def run(a):return subprocess.run(a,check=True,capture_output=True)
meta=json.loads(run(['ffprobe','-v','error','-count_frames','-show_entries','format=duration:stream=codec_name,width,height,r_frame_rate,nb_read_frames,duration','-of','json',str(p)]).stdout)
v=next(a for a in meta['streams'] if 'width' in a);assert v['width']==1920 and v['height']==1080 and v['r_frame_rate']=='30/1' and int(v['nb_read_frames'])==240
run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(p),'-f','null','-'])
black=run(['ffmpeg','-hide_banner','-loglevel','info','-i',str(p),'-vf','blackdetect=d=0.06:pix_th=0.04:pic_th=0.99','-an','-f','null','-']).stderr.decode();black=[l for l in black.splitlines() if 'black_start:' in l];assert not black
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(p),'-vn','-ar','16000','-ac','1','-f','f32le','/tmp/rework-audio.f32'])
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',str(836/30),'-i',str(root/'public/music.mp3'),'-t','8','-vn','-ar','16000','-ac','1','-f','f32le','/tmp/rework-source.f32'])
x=np.fromfile('/tmp/rework-source.f32',dtype='float32');y=np.fromfile('/tmp/rework-audio.f32',dtype='float32');c=correlate(y,x,method='fft');lag=int(correlation_lags(len(y),len(x))[np.argmax(c)])
if lag>=0:aa=x[:min(len(x),len(y)-lag)];bb=y[lag:lag+len(aa)]
else:bb=y[:min(len(y),len(x)+lag)];aa=x[-lag:-lag+len(bb)]
rho=float(np.corrcoef(aa,bb)[0,1]);assert abs(lag)/16000<1/30 and rho>.98
font=TTFont(root/'public/fonts/SummerBlack.ttf').getBestCmap();chars='很贪心要全世界注意欲望全球广播';missing=[ch for ch in set(chars) if ord(ch) not in font];assert not missing
bounds=json.loads((root/'output/rework/painted-bounds-qa.json').read_text());assert bounds['checkedFrames']==240 and not bounds['errors']
# Only these authored entry/overshoot intervals may leave the frame. Stable composition must stay intact.
allowed={'贪':[(46,56)],'要':[(111,116)],'全':[(129,133)],'世':[(144,146)],'界':[(155,158)],'意':[(196,198)]}
remaining=[]
for a in bounds['warnings']:
 for b in a['items']:
  if not any(lo<=a['frame']<=hi for lo,hi in allowed.get(b['text'],[])):remaining.append(a)
assert not remaining,remaining
report={'status':'passed','video':v,'containerDurationSeconds':float(meta['format']['duration']),'allVideoFramesDecoded':240,'blackIntervals':black,'audioSourceStartSeconds':836/30,'audioSourceLagSeconds':lag/16000,'audioCorrelation':rho,'lyricGlyphsMissing':missing,'allFrameGeometryErrors':len(bounds['errors']),'entryOvershootWarningsReviewed':len(bounds['warnings']),'unresolvedSettledGlyphCropping':remaining,'reviewedSecondFrames':[0,30,60,90,120,150,180,210,239],'reviewedTransitionFrames':[45,46,51,56,64,65,67,110,111,115,120,128,129,133,146,158,167,168,173,195,196,206,215],'artReviewLimit':'Artistic approval is a design judgment, not established by these technical checks. Source lyric timestamps and measured transients were used; no human word-by-word audio listening or ASR alignment is claimed.'}
(root/'output/rework/media-qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
