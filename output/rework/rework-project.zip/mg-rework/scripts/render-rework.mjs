import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderMedia,
  renderStill,
} from "@remotion/renderer";
import fs from "node:fs";
import path from "node:path";
const mode = process.argv[2] ?? "video";
const version = process.argv[3] ?? "v3";
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
const browser = await openBrowser("chrome", {
  browserExecutable: "/usr/bin/chromium",
  logLevel: "error",
});
try {
  const c = await selectComposition({
    serveUrl,
    id: "Rework8Sec",
    puppeteerInstance: browser,
  });
  if (mode === "stills") {
    for (const f of [
      0, 15, 30, 45, 50, 56, 60, 65, 67, 75, 90, 106, 114, 120, 128, 132, 140,
      146, 158, 167, 173, 180, 191, 198, 206, 214, 225, 239,
    ]) {
      await renderStill({
        serveUrl,
        composition: c,
        frame: f,
        output: `rework/review/frame-${String(f).padStart(3, "0")}.png`,
        puppeteerInstance: browser,
      });
      console.log("Frame", f);
    }
  } else {
    let last = -10;
    await renderMedia({
      serveUrl,
      composition: c,
      puppeteerInstance: browser,
      outputLocation: `output/rework/sample-${version}.mp4`,
      codec: "h264",
      crf: 16,
      audioCodec: "aac",
      audioBitrate: "320k",
      pixelFormat: "yuv420p",
      imageFormat: "jpeg",
      jpegQuality: 98,
      concurrency: 3,
      onProgress: ({ progress }) => {
        const p = Math.floor(progress * 100);
        if (p >= last + 10) {
          last = p;
          console.log("Render", p + "%");
        }
      },
    });
    console.log("Rendered 240-frame sample");
  }
} finally {
  await browser.close({ silent: true });
}
