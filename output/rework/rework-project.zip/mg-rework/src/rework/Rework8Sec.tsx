import {
  AbsoluteFill,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Audio } from "@remotion/media";
import "../design";
import {
  P,
  H,
  ramp,
  linear,
  weight,
  hit,
  Type,
  Mini,
  Grain,
  Love,
  Actor,
  Pointer,
} from "./visual-language";

// A single phrase becomes a causal sequence of different viewpoints.
// Authored word anchors are from source YRC. Impact peaks follow measured audio transients.
const Very = ({ f }: { f: number }) => {
  const arrive = weight(f, 0, 20);
  const push = ramp(f, 23, 45, 0, 110);
  const beat = hit(f, 5, 1);
  return (
    <g>
      <rect width="1920" height="1080" fill={P.paper} />
      <Grain />
      <g transform={`translate(${-push} 0)`}>
        <Type
          text="很"
          x={855 + (1 - arrive) * -130}
          y={890 + (1 - arrive) * 20}
          size={870}
          color={P.black}
          dx={30}
          dy={42}
          depth={14}
          shadow={P.orange}
          scale={1.05 - arrive * 0.05}
          rotate={-4 + (1 - arrive) * 8}
        />
        <Actor
          x={184 + push * 0.4}
          y={630 + (1 - arrive) * 30}
          size={356}
          f={f}
          mood="want"
          angle={-6 + beat * 2}
          sx={1 + beat * 0.04}
          sy={1 - beat * 0.05}
          arm={ramp(f, 26, 45, 0, 3)}
        />
        <Love
          x={648 - ramp(f, 24, 45, 0, 110)}
          y={410 + ramp(f, 22, 45, 0, 70)}
          size={91}
          color={P.blue}
          rotate={-16 + ramp(f, 0, 40, 0, 10)}
        />
        <Love
          x={750 - ramp(f, 24, 45, 0, 102)}
          y={569 - ramp(f, 24, 45, 0, 31)}
          size={43}
          color={P.orange}
          rotate={13}
        />
        <path d="M103 942H661" stroke={P.black} strokeWidth={4} />
        <path d="M103 942V916M661 942V916" stroke={P.black} strokeWidth={4} />
        <Mini text="MORE. AND MORE." x={120} y={1005} size={24} />
        <Mini text="欲望 / 01" x={116} y={112} size={24} />
      </g>
      <g
        opacity={ramp(f, 36, 45, 0, 1)}
        stroke={P.black}
        fill="none"
        strokeWidth={3}
      >
        <path d="M780 620L672 625L700 601M672 625L700 647" />
        <circle cx={628} cy={611} r={8} />
      </g>
    </g>
  );
};
const Greed = ({ f }: { f: number }) => {
  const slam = weight(f, 50, 14, 290);
  const smear = Math.min(
    19,
    Math.abs((slam - weight(f - 0.65, 50, 14, 290)) * 820) / 5.2,
  );
  const impact = hit(f, 56, 12);
  const pull = linear(f, 49, 66);
  return (
    <g>
      <rect width="1920" height="1080" fill={P.paper} />
      <defs>
        <filter id="greed-smear" x="-30%" y="-20%" width="160%" height="140%">
          <feGaussianBlur stdDeviation={`${smear} 0.4`} />
        </filter>
      </defs>
      <path
        d={`M${1190 + impact} 0H1920V1080H${870 + impact}Z`}
        fill={P.blue}
      />
      <g transform={`translate(${impact} ${-impact * 0.5})`}>
        <Type
          text="贪"
          filterId="greed-smear"
          x={140 + (1 - slam) * -820}
          y={875}
          size={825}
          rotate={-8 + (1 - slam) * 20}
          color={P.black}
          dx={35}
          dy={42}
          depth={16}
          shadow={P.orange}
        />
        <Type text="很" x={146} y={152} size={100} color={P.black} />
        <Actor
          x={1260 - pull * 90}
          y={623 + impact * 0.3}
          size={339}
          f={f}
          color={P.orange}
          mood="want"
          arm={4 + pull * 5}
          angle={-pull * 9}
          sx={1 + pull * 0.07}
          sy={1 - pull * 0.04}
        />
        {Array.from({ length: 6 }, (_, i) => {
          const q = linear(f, 48 + i * 0.75, 64 + i * 0.3);
          return (
            <Love
              key={i}
              x={1760 - i * 91 + (1260 - (1760 - i * 91)) * q}
              y={140 + (i % 3) * 121 + (705 - (140 + (i % 3) * 121)) * q}
              size={50 + (i % 3) * 25}
              color={i % 2 ? P.paper : P.orange}
              rotate={i * 13 + q * 40}
              opacity={1 - ramp(f, 63, 67)}
            />
          );
        })}
        <Mini text="I WANT IT ALL" x={1144} y={132} color={P.paper} size={30} />
      </g>
    </g>
  );
};
const HeartFace = ({ f }: { f: number }) => {
  const drop = weight(f, 65, 19, 255);
  const throb = hit(f, 67, 0.075) + hit(f, 81, 0.025) + hit(f, 106, 0.025);
  const eye = linear(f, 65, 75);
  const squash = 1 + throb;
  const emotionPush = ramp(f, 76, 109, 0, 0.048);
  return (
    <g>
      <rect width="1920" height="1080" fill={P.orange} />
      <g
        transform={`translate(960 540) scale(${1.25 - drop * 0.25 + throb * 0.15 + emotionPush}) translate(-960 -540)`}
      >
        <rect
          x={473}
          y={132}
          width={174}
          height={239 - eye * 65}
          fill={P.black}
        />
        <rect
          x={1274}
          y={132}
          width={174}
          height={239 - eye * 65}
          fill={P.black}
        />
        <Love
          x={494}
          y={151}
          size={134}
          color={P.paper}
          scale={eye * (1 + Math.max(0, throb) * 2)}
        />
        <Love
          x={1294}
          y={151}
          size={134}
          color={P.paper}
          scale={eye * (1 + Math.max(0, throb) * 2)}
        />
        <path d="M300 397H472V449H300ZM1437 397H1608V449H1437Z" fill={P.warm} />
        <g
          transform={`translate(960 740) scale(${squash} ${1 - throb * 0.4}) translate(-960 -740)`}
        >
          <Type
            text="心"
            x={628}
            y={900}
            size={654}
            color={P.paper}
            dx={26}
            dy={25}
            depth={11}
            shadow={P.black}
            rotate={-4 + hit(f, 67, 2.7)}
          />
        </g>
        <Type text="贪" x={260} y={250} size={111} color={P.black} />
        <Mini
          text="GREED LEVEL: MAX"
          x={1258}
          y={995}
          color={P.black}
          size={24}
        />
      </g>
      {Array.from({ length: 8 }, (_, i) => (
        <rect
          key={i}
          x={75 + i * 235}
          y={1029}
          width={ramp(f, 65 + i * 2, 86 + i * 2, 0, 160)}
          height={8}
          fill={P.black}
        />
      ))}
    </g>
  );
};
const Want = ({ f }: { f: number }) => {
  const p = weight(f, 115, 14, 270);
  const smear = Math.min(
    17,
    Math.abs((p - weight(f - 0.65, 115, 14, 270)) * 600) / 5.2,
  );
  const boom = hit(f, 120, 17);
  const anticipation = ramp(f, 111, 115, 0, 0.1);
  return (
    <g>
      <rect width="1920" height="1080" fill={P.blue} />
      <Grain color={P.paper} opacity={0.15} />
      <defs>
        <filter id="want-smear" x="-30%" y="-20%" width="160%" height="140%">
          <feGaussianBlur stdDeviation={`${smear} 0.4`} />
        </filter>
      </defs>
      <Type
        text="要"
        filterId="want-smear"
        x={486 + (1 - p) * 600}
        y={936 + (1 - p) * -220}
        size={960}
        color={P.paper}
        dx={37}
        dy={46}
        depth={17}
        shadow={P.black}
        scale={1 - anticipation + (p > 0 ? anticipation * p : 0)}
        rotate={-5 + (1 - p) * 29 + boom * 0.07}
      />
      <Pointer
        x={ramp(f, 112, 122, 1650, 1440) + boom}
        y={ramp(f, 112, 122, 730, 741) + boom * 0.3}
        size={175}
        rotate={-13 + boom * 0.1}
      />
      {f >= 120 && (
        <g
          stroke={P.orange}
          strokeWidth={13}
          fill="none"
          opacity={linear(f, 120, 128, 1, 0)}
        >
          <path d="M1457 644L1465 585M1514 682L1571 652M1389 694L1331 674" />
        </g>
      )}
      <Mini
        text="REQUEST: THE WHOLE WORLD"
        x={76}
        y={92}
        color={P.paper}
        size={24}
      />
    </g>
  );
};
const World = ({ f }: { f: number }) => {
  const sweep = ramp(f, 129, 141, 1920, 862);
  const angle = ramp(f, 130, 158, -7, 0);
  const full = weight(f, 129, 17, 235);
  const second = weight(f, 144, 17, 235);
  const third = weight(f, 155, 16, 245);
  return (
    <g>
      <rect width="1920" height="1080" fill={P.paper} />
      <path d={`M${sweep + 253} 0H1920V1080H${sweep}Z`} fill={P.blue} />
      <g transform={`rotate(${angle} 960 540)`}>
        <defs>
          <clipPath id="world-disc">
            <circle cx={1470} cy={312} r={453} />
          </clipPath>
        </defs>
        <circle
          cx={1470}
          cy={312}
          r={453}
          fill={P.blue}
          stroke={P.black}
          strokeWidth={7}
        />
        <g
          clipPath="url(#world-disc)"
          transform={`rotate(${linear(f, 129, 169, -27, 10)} 1470 312)`}
          fill={P.paper}
        >
          <path d="M1090 39H1261V91H1303V149H1394V216H1341V303H1248V380H1153V329H1113V237H1041V156H1090ZM1471 355H1606V417H1688V507H1662V583H1571V519H1490ZM1682 90H1819V190H1794V263H1742V314H1646V245H1615V171H1682Z" />
          <path
            d="M1485 -82V97H1563V165H1445V230H1511V310H1421V362H1471V436"
            fill="none"
            stroke={P.orange}
            strokeWidth={31}
          />
        </g>
        <g transform={`translate(${hit(f, 133, 9)} ${hit(f, 133, 4)})`}>
          <Type
            text="全"
            x={190 + (1 - full) * -475}
            y={576 + (1 - full) * 245}
            size={510}
            rotate={-12 + (1 - full) * -25}
            color={P.black}
          />
        </g>
        <Type
          text="世"
          opacity={f >= 144 ? 1 : 0}
          x={675 + (1 - second) * 110}
          y={790 + (1 - second) * -790}
          size={531}
          rotate={7 + (1 - second) * 24}
          color={P.black}
          dx={20}
          dy={21}
          depth={7}
          shadow={P.orange}
        />
        <Type
          text="界"
          opacity={f >= 155 ? 1 : 0}
          x={1285 + (1 - third) * 620}
          y={970}
          size={455}
          rotate={-7 + (1 - third) * -31}
          color={P.paper}
          dx={19}
          dy={23}
          depth={9}
          shadow={P.black}
        />
        <Actor
          x={203 + ramp(f, 129, 169, 0, 83)}
          y={785 - Math.max(0, hit(f, 146, 25))}
          size={187}
          f={f}
          mood="happy"
          angle={-3}
        />
        <Actor
          x={477 + ramp(f, 129, 169, 0, 53)}
          y={779 - Math.max(0, hit(f, 158, 22))}
          size={174}
          f={f}
          color={P.blue}
          mood="happy"
          angle={4}
        />
        <Mini text="OUR SMALL WORLD / 02" x={74} y={1044} size={24} />
      </g>
    </g>
  );
};
const Attention = ({ f }: { f: number }) => {
  const take = weight(f, 168, 21, 260);
  const squeeze = hit(f, 173, 14);
  const intent = weight(f, 196, 15, 245);
  const tail = weight(f, 215, 16, 235);
  const columnSplit = (1 - ramp(f, 168, 178)) * 108;
  const lowerFollow = hit(f, 206, 12) + hit(f, 214, 7);
  return (
    <g>
      <rect width="1920" height="1080" fill={P.black} />
      {/* The old world becomes the little notification's origin, then is swallowed by its scale. */}
      {[0, 1, 2].map((i) => (
        <g
          key={i}
          transform={`translate(${112 + i * 15} ${52 + i * 12}) rotate(${(i - 1) * 2})`}
          opacity={0.48}
        >
          <rect width="1690" height="900" fill={i % 2 ? P.blue : P.orange} />
          <rect x={4} y={4} width="1682" height="41" fill={P.black} />
        </g>
      ))}
      <g
        transform={`translate(${960 + squeeze} ${540 - squeeze * 0.5}) rotate(${hit(f, 173, 0.7)}) scale(${0.13 + 0.87 * take}) translate(-960 -540)`}
      >
        <rect
          x={62}
          y={54}
          width="1796"
          height="974"
          fill={P.paper}
          stroke={P.black}
          strokeWidth={7}
        />
        <rect x={66} y={58} width="1788" height="73" fill={P.blue} />
        <Actor x={84} y={76} size={60} f={f} color={P.orange} mood="happy" />
        <Mini
          text="attention.exe — OPEN TO EVERYONE"
          x={166}
          y={104}
          size={25}
          color={P.paper}
        />
        <g fill={P.paper} stroke={P.black} strokeWidth={3}>
          <rect x={1708} y={76} width={39} height={33} />
          <rect x={1754} y={76} width={39} height={33} />
          <rect x={1800} y={76} width={39} height={33} />
        </g>
        <g stroke={P.black} strokeWidth={4}>
          <path d="M1718 96H1738M1763 84H1784V102H1763ZM1809 84L1830 103M1830 84L1809 103" />
        </g>
        <Mini
          text="全球广播 / PLEASE PAY ATTENTION"
          x={120}
          y={193}
          size={23}
        />
        <defs>
          <clipPath id="water-part">
            <rect x={100} y={200} width={252} height={700} />
          </clipPath>
          <clipPath id="main-part">
            <rect x={352} y={200} width={575} height={700} />
          </clipPath>
          <clipPath id="intent-top">
            <rect x={910} y={200} width={700} height={475} />
          </clipPath>
          <clipPath id="intent-heart">
            <rect x={910} y={675} width={700} height={275} />
          </clipPath>
        </defs>
        <g
          clipPath="url(#water-part)"
          transform={`translate(${-columnSplit} 0)`}
        >
          <Type
            text="注"
            x={129}
            y={839}
            size={750}
            color={P.black}
            dx={23}
            dy={25}
            depth={9}
            shadow={P.orange}
          />
        </g>
        <g
          clipPath="url(#main-part)"
          transform={`translate(${columnSplit * 0.6} 0)`}
        >
          <Type
            text="注"
            x={129}
            y={839}
            size={750}
            color={P.black}
            dx={23}
            dy={25}
            depth={9}
            shadow={P.orange}
          />
        </g>
        {f >= 196 && (
          <g
            transform={`translate(${1250 + (1 - intent) * 570} ${690 - (1 - intent) * 380}) rotate(${-11 + (1 - intent) * -32}) scale(${0.74 + 0.26 * intent}) translate(-1250 -690)`}
          >
            <g clipPath="url(#intent-top)">
              <Type
                text="意"
                x={936}
                y={834}
                size={728}
                color={P.blue}
                dx={23}
                dy={25}
                depth={10}
                shadow={P.black}
              />
            </g>
            <g
              clipPath="url(#intent-heart)"
              transform={`translate(0 ${lowerFollow})`}
            >
              <Type
                text="意"
                x={936}
                y={834}
                size={728}
                color={P.blue}
                dx={23}
                dy={25}
                depth={10}
                shadow={P.black}
              />
            </g>
          </g>
        )}
        {f >= 215 && (
          <Type
            text="!"
            x={1640}
            y={886}
            size={305}
            color={P.orange}
            dx={14}
            dy={17}
            depth={8}
            shadow={P.black}
            scale={tail}
            rotate={8 + (1 - tail) * 30}
          />
        )}
        <Pointer
          x={ramp(f, 177, 202, 1680, 1750)}
          y={ramp(f, 177, 202, 673, 926)}
          size={92}
          rotate={-5}
        />
        <g opacity={ramp(f, 222, 227)}>
          <path d="M118 927H1786" stroke={P.black} strokeWidth={3} />
          <text
            data-hero="完整歌词"
            x={124}
            y={994}
            fill={P.black}
            fontFamily={H}
            fontSize={52}
            letterSpacing={3}
          >
            很贪心，要全世界注意
          </text>
          <Mini text="ON AIR" x={1640} y={994} color={P.blue} size={24} />
        </g>
        <g
          stroke={P.orange}
          strokeWidth={5}
          fill="none"
          opacity={linear(f, 173, 185, 1, 0)}
        >
          <path d="M1500 300V228M1580 338L1635 283M1417 334L1360 279" />
        </g>
      </g>
    </g>
  );
};
export const Rework8Sec = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: P.paper }}>
      <Audio
        src={staticFile("music.mp3")}
        trimBefore={836}
        durationInFrames={8 * fps}
        premountFor={fps}
      />
      <svg
        width="1920"
        height="1080"
        viewBox="0 0 1920 1080"
        style={{ overflow: "hidden" }}
      >
        {f < 46 ? (
          <Very f={f} />
        ) : f < 65 ? (
          <Greed f={f} />
        ) : f < 111 ? (
          <HeartFace f={f} />
        ) : f < 129 ? (
          <Want f={f} />
        ) : f < 168 ? (
          <World f={f} />
        ) : (
          <Attention f={f} />
        )}
      </svg>
    </AbsoluteFill>
  );
};
