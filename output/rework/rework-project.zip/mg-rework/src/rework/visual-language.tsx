import React from "react";
import { Easing, interpolate, spring } from "remotion";
export const P = {
  paper: "#F1F0E9",
  black: "#111214",
  blue: "#315DE7",
  orange: "#DF784E",
  warm: "#FFA173",
  gray: "#AEADA6",
};
export const H = "SummerBlack";
export const M = "MemoryMono";
export const ramp = (f: number, a: number, b: number, x = 0, y = 1) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.16, 1, 0.3, 1),
  });
export const linear = (f: number, a: number, b: number, x = 0, y = 1) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
export const weight = (f: number, a: number, damping = 16, stiffness = 230) =>
  spring({ frame: f - a, fps: 30, config: { damping, stiffness, mass: 0.82 } });
export const hit = (f: number, a: number, amplitude = 1) =>
  f < a ? 0 : Math.cos((f - a) * 2.25) * amplitude * Math.exp(-(f - a) / 5);
export const glyph = (
  ch: string,
  x: number,
  y: number,
  size: number,
  color: string,
  extra: React.SVGProps<SVGTextElement> = {},
) => (
  <text
    data-hero={ch}
    x={x}
    y={y}
    fontFamily={H}
    fontWeight={900}
    fontSize={size}
    fill={color}
    letterSpacing={-size * 0.03}
    {...extra}
  >
    {ch}
  </text>
);
export const Type = ({
  text,
  x,
  y,
  size,
  color = P.black,
  dx = 0,
  dy = 0,
  depth = 0,
  shadow = P.black,
  rotate = 0,
  scale = 1,
  opacity = 1,
  filterId,
}: {
  filterId?: string;
  text: string;
  x: number;
  y: number;
  size: number;
  color?: string;
  dx?: number;
  dy?: number;
  depth?: number;
  shadow?: string;
  rotate?: number;
  scale?: number;
  opacity?: number;
}) => (
  <g
    transform={`translate(${x} ${y}) rotate(${rotate}) scale(${Math.max(0.001, scale)})`}
    opacity={opacity}
    filter={filterId ? `url(#${filterId})` : undefined}
  >
    {depth > 0 &&
      Array.from({ length: depth }, (_, i) =>
        glyph(
          text,
          ((depth - i) * dx) / depth,
          ((depth - i) * dy) / depth,
          size,
          shadow,
          { key: i, "aria-hidden": true },
        ),
      )}
    {glyph(text, 0, 0, size, color)}
  </g>
);
export const Mini = ({
  text,
  x,
  y,
  color = P.black,
  size = 24,
}: {
  text: string;
  x: number;
  y: number;
  color?: string;
  size?: number;
}) => (
  <text
    x={x}
    y={y}
    fill={color}
    fontFamily={`${M}, ${H}`}
    fontSize={size}
    letterSpacing={1}
  >
    {text}
  </text>
);
export const Grain = ({
  color = P.black,
  opacity = 0.12,
}: {
  color?: string;
  opacity?: number;
}) => (
  <g opacity={opacity} fill={color}>
    {Array.from({ length: 22 }, (_, i) =>
      Array.from({ length: 14 }, (_, j) => (
        <circle key={`${i}-${j}`} cx={1340 + i * 24} cy={58 + j * 24} r={1.4} />
      )),
    )}
  </g>
);
export const Love = ({
  x,
  y,
  size = 80,
  color = P.orange,
  rotate = 0,
  scale = 1,
  opacity = 1,
}: {
  x: number;
  y: number;
  size?: number;
  color?: string;
  rotate?: number;
  scale?: number;
  opacity?: number;
}) => (
  <g
    transform={`translate(${x} ${y}) rotate(${rotate}) scale(${(size / 11) * Math.max(0, scale)})`}
    opacity={opacity}
    fill={color}
    shapeRendering="crispEdges"
  >
    <path d="M1 1H4V2H5V3H6V2H7V1H10V2H11V6H10V7H9V8H8V9H7V10H6V11H5V10H4V9H3V8H2V7H1V6H0V2H1Z" />
  </g>
);
export const Actor = ({
  x,
  y,
  size = 200,
  color = P.orange,
  f = 0,
  mood = "open",
  angle = 0,
  sx = 1,
  sy = 1,
  arm = 0,
}: {
  x: number;
  y: number;
  size?: number;
  color?: string;
  f?: number;
  mood?: "open" | "happy" | "want" | "hearts";
  angle?: number;
  sx?: number;
  sy?: number;
  arm?: number;
}) => (
  <g
    transform={`translate(${x} ${y}) rotate(${angle}) scale(${(size / 24) * sx} ${(size / 24) * sy})`}
    shapeRendering="crispEdges"
  >
    <g fill={color}>
      <path d="M5 3H18V5H21V8H24V13H21V17H3V14H0V9H3V5H5Z" />
      <rect x="6" y="0" width="3" height="4" />
      <rect x="16" y="1" width="3" height="4" />
      <rect x="4" y="16" width="4" height="4" />
      <rect x="16" y="16" width="4" height="4" />
      <rect x="21" y={8 - arm} width="5" height="3" />
    </g>
    <g fill={P.black}>
      {mood === "happy" ? (
        <path d="M6 8H7V7H9V8H10V9H9V8H7V9H6ZM14 8H15V7H17V8H18V9H17V8H15V9H14Z" />
      ) : (
        <>
          <rect
            x="6"
            y={f % 110 > 105 ? 9 : 7}
            width={mood === "want" ? 3 : 2}
            height={f % 110 > 105 ? 1 : 4}
          />
          <rect
            x="15"
            y={f % 110 > 105 ? 9 : 7}
            width={mood === "want" ? 3 : 2}
            height={f % 110 > 105 ? 1 : 4}
          />
        </>
      )}
      <path d={mood === "want" ? "M10 12H15V15H10Z" : "M10 12H14V13H10Z"} />
    </g>
    <path d="M4 11H7V12H4ZM17 11H20V12H17Z" fill={P.warm} />
  </g>
);
export const Pointer = ({
  x,
  y,
  size = 90,
  rotate = 0,
}: {
  x: number;
  y: number;
  size?: number;
  rotate?: number;
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rotate}) scale(${size / 50})`}>
    <path
      d="M3 2V45L15 32L27 56L37 51L26 29L44 28Z"
      fill={P.black}
      stroke={P.paper}
      strokeWidth={3}
      strokeLinejoin="miter"
    />
  </g>
);
