# NoPC CAE — strict INP C3D4 solve

- Method: strict imported Abaqus/CalculiX-style INP C3D4 isotropic linear statics
- Status: **computed, NOT experimentally or industrially validated**
- Nodes: 4; tetrahedra: 1
- Max displacement: 0.00636734693878 m
- Max von Mises stress: 342.857142857 Pa
- Total applied force (N): [0.0, 0.0, -100.0]
- Total support reaction (N): [0.0, 0.0, 100.0]
- Force residual: 0
- Free-DOF residual: 0
- Energy check: 0

**Scope:** one material, small-strain isotropic linear static C3D4 with nodal forces and zero displacements. No contact, composite failure, nonlinear mechanics, UMAT or VUMAT. Abaqus INP units were confirmed as SI by CLI flag, not inferred automatically.

Reproduction: `nopc-bridge solve-inp source.inp --units SI --out recheck`. `fields.npz` contains the actual nodal/element arrays. No independent reference or experimental data were supplied.
