# NoPC CAE computed baseline result

- Analysis: small-strain isotropic linear FEM, C3D4 tetrahedron
- Status: **computed, NOT experimentally or industrially validated**
- Precision request: research
- Nodes: 45; tetrahedra: 96
- End displacement: 1.42857142857e-07 m
- Maximum von Mises: 10000 Pa
- Fixed-support reaction X: -100 N
- Force equilibrium residual: 5.684e-16
- Free-DOF solver residual: 4.189e-14
- Internal/external energy check: 1.21e-14

**Scope:** no damage, nonlinear contact, transient impact, or VUMAT. There is no experimental validation, and this single patch test must not be taken as an industrial design certificate.

Reproduction: `nopc-bridge run case_used.json --out rerun`. Input is SI. Files `fields.npz` and `result.vtk` hold actual computed fields.

- Analytic (nu=0) mean end-displacement relative error: 9.079e-15
