# NoPC CAE Cloud Bridge v0.1 — Actual run evidence

## Date and environment

- Date: 2026-10-09 (environment system clock; platform provider differs from Codex Cloud)
- Execution location: **current ChatGPT tool container**, NOT user's Codex Cloud.
- Python: 3.13.5; NumPy and SciPy available.
- CalculiX available here: **False**.
- OpenRadioss starter available here: **False**.
- OpenRadioss engine available here: **False**.
- Attempted apt package index update to assess CalculiX; timed out (exit status 124). Did not execute ccx/OpenRadioss.

## Real calculated baseline

- Native solver: sparse tetrahedral C3D4 3D small-strain elasticity, x=0 clamped, x=L uniform total +100 N applied to x=L face.
- Actual mesh: 96 tetrahedra / 45 nodes.
- Axial end displacement: 1.42857142857142e-07 m.
- Analytical displacement, nu=0: 1.42857142857143e-07 m.
- Relative analytic discrepancy: 9.07913e-15.
- Max von Mises: 10000 Pa.
- Support reaction X: -99.9999999999999 N.
- Force balance relative error: 5.68434e-16.
- Free DOF residual: 4.18933e-14.
- Energy balance relative error: 1.20956e-14.
- Three uniform-field mesh levels: [{'subdivisions': {'nx': 4, 'ny': 2, 'nz': 2}, 'n_tets': 96, 'mean_end_ux_m': 1.4285714285714155e-07}, {'subdivisions': {'nx': 8, 'ny': 4, 'nz': 4}, 'n_tets': 768, 'mean_end_ux_m': 1.4285714285713657e-07}, {'subdivisions': {'nx': 12, 'ny': 6, 'nz': 6}, 'n_tets': 2592, 'mean_end_ux_m': 1.4285714285713837e-07}].
- Displacement spread among refinements: 3.48342e-14 (patch test; not generalized error control).

## Automated verification

- See `docs/test_results.txt`: 21 passing tests.
- Includes analytical benchmark, mesh orientation, positive/invalid material, negative load, result export and ZIP, engineering certification prohibition, input audits, malicious INCLUDE path rejection, mock CalculiX process success/fail and mock OpenRadioss process output.
- Mock tests **are not actual external FEM solver tests**. No 3D composite damage, VUMAT or full explicit impact solver was executed.

## Result artifacts

- `runs/research_final/case_used.json`: numerical input used.
- `runs/research_final/result.json`: metrics and mesh refinement data.
- `runs/research_final/fields.npz`: computed node/element arrays.
- `runs/research_final/result.vtk`: 3D mesh and stress/displacement fields.
- `runs/research_final/report.html`: standalone mobile-readable report with embedded actual displacement chart.
- `runs/research_final/manifest.json`: input, solver-source, result file SHA256.

## Interpretive limit

Correct reproduction of a homogeneous bar patch solution does not validate a VUMAT, a composite impact damage model, large-strain surface contact, or industrial-grade prediction. A separately running Codex Cloud task and real external binaries are required to validate the proposed cloud integration.
