这些文件记录之前 Cloud Bridge v0.1.0 的测试，不属于 v0.2.0 当前验收记录。请查阅 `../V02_VALIDATION.md` 与 `../verification/` 目录核对新版的实际运行结果。
